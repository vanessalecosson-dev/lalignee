<?php
/**
 * La Lignée — functions
 */
if (!defined('ABSPATH')) exit;

define('LA_LIGNEE_VERSION', '1.3.0');

/* ---------- Modules ---------- */
require_once get_template_directory() . '/inc/cpt-realisations.php';
require_once get_template_directory() . '/inc/cpt-faq.php';
require_once get_template_directory() . '/inc/settings-contact.php';
require_once get_template_directory() . '/inc/contact-form.php';

/* ---------- Setup ---------- */
function la_lignee_setup() {
    load_theme_textdomain('la-lignee', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 280,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/main.css');

    register_nav_menus(array(
        'primary' => __('Menu principal', 'la-lignee'),
        'footer'  => __('Menu pied de page', 'la-lignee'),
    ));

    // Image sizes
    add_image_size('la-lignee-card', 720, 540, true);
    add_image_size('la-lignee-hero', 1600, 900, true);
}
add_action('after_setup_theme', 'la_lignee_setup');

/* ---------- Enqueue ---------- */
function la_lignee_assets() {
    // Google fonts
    wp_enqueue_style(
        'la-lignee-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,400&family=Jost:wght@300;400;500&display=swap',
        array(), null
    );
    wp_enqueue_style('la-lignee-main', get_template_directory_uri() . '/assets/css/main.css', array('la-lignee-fonts'), LA_LIGNEE_VERSION);

    wp_enqueue_script('la-lignee-main', get_template_directory_uri() . '/assets/js/main.js', array(), LA_LIGNEE_VERSION, true);
    wp_localize_script('la-lignee-main', 'LALIGNEE', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('la_lignee_contact'),
    ));

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'la_lignee_assets');

/* ---------- Widgets / Sidebar ---------- */
function la_lignee_widgets() {
    register_sidebar(array(
        'name'          => __('Pied de page — Colonne 1', 'la-lignee'),
        'id'            => 'footer-1',
        'before_widget' => '<div class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5>',
        'after_title'   => '</h5>',
    ));
}
add_action('widgets_init', 'la_lignee_widgets');

/* ---------- Excerpt ---------- */
function la_lignee_excerpt_length($length) { return 22; }
add_filter('excerpt_length', 'la_lignee_excerpt_length');
function la_lignee_excerpt_more($more) { return '…'; }
add_filter('excerpt_more', 'la_lignee_excerpt_more');

/* ---------- Pagination ---------- */
function la_lignee_pagination() {
    the_posts_pagination(array(
        'mid_size'  => 2,
        'prev_text' => '←',
        'next_text' => '→',
        'screen_reader_text' => ' ',
    ));
}

/* ---------- Contact form: handler déplacé dans inc/contact-form.php ---------- */

/* ---------- Customizer ---------- */
function la_lignee_customize($wp_customize) {
    $wp_customize->add_section('la_lignee_contact', array(
        'title'    => __('La Lignée — Contact', 'la-lignee'),
        'priority' => 40,
    ));

    $fields = array(
        'email'     => array('label' => 'Email de contact', 'default' => 'contact@lalignee.ci'),
        'phone'     => array('label' => 'Téléphone', 'default' => '+225 00 00 00 00'),
        'address'   => array('label' => 'Adresse', 'default' => 'Abidjan, Côte d\'Ivoire'),
        'instagram' => array('label' => 'Instagram (URL)', 'default' => ''),
        'linkedin'  => array('label' => 'LinkedIn (URL)', 'default' => ''),
    );

    foreach ($fields as $key => $f) {
        $wp_customize->add_setting('la_lignee_' . $key, array(
            'default'           => $f['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('la_lignee_' . $key, array(
            'label'   => $f['label'],
            'section' => 'la_lignee_contact',
            'type'    => 'text',
        ));
    }

    // Contact email receiver
    $wp_customize->add_setting('la_lignee_contact_email', array(
        'default'           => get_option('admin_email'),
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('la_lignee_contact_email', array(
        'label'       => __('Recevoir les messages sur (email)', 'la-lignee'),
        'section'     => 'la_lignee_contact',
        'type'        => 'email',
        'description' => 'Adresse qui recevra les soumissions du formulaire.',
    ));

    // Hero
    $wp_customize->add_section('la_lignee_hero', array('title' => __('La Lignée — Accueil (Hero)', 'la-lignee'), 'priority' => 30));
    $hero = array(
        'hero_eyebrow' => array('label' => 'Petit texte au-dessus', 'default' => 'Conseil & stratégie · Abidjan'),
        'hero_tag'     => array('label' => 'Phrase manifeste', 'default' => 'Penser juste, déployer vite, décider par la preuve. Nous accompagnons les marques qui veulent grandir avec méthode.'),
        'hero_sub'     => array('label' => 'Sous-ligne (pôles)', 'default' => 'Stratégie · Digital & Tech · Data'),
    );
    foreach ($hero as $k => $f) {
        $wp_customize->add_setting('la_lignee_' . $k, array('default' => $f['default'], 'sanitize_callback' => 'sanitize_text_field'));
        $wp_customize->add_control('la_lignee_' . $k, array('label' => $f['label'], 'section' => 'la_lignee_hero', 'type' => 'textarea'));
    }
}
add_action('customize_register', 'la_lignee_customize');

function la_lignee_opt($key, $fallback = '') {
    $v = get_theme_mod('la_lignee_' . $key, $fallback);
    return $v !== '' ? $v : $fallback;
}

/* ---------- Body class ---------- */
function la_lignee_body_class($classes) {
    if (is_page_template('page-home.php') || is_front_page()) { $classes[] = 'home-page'; }
    return $classes;
}
add_filter('body_class', 'la_lignee_body_class');
