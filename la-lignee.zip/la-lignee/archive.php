<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<header class="page-header">
  <p class="eyebrow"><?php
    if (is_category()) echo 'Catégorie';
    elseif (is_tag()) echo 'Étiquette';
    elseif (is_author()) echo 'Auteur';
    else echo 'Archives';
  ?></p>
  <h1><?php the_archive_title(); ?></h1>
  <?php if (get_the_archive_description()) : ?>
    <p class="lead"><?php echo wp_kses_post(get_the_archive_description()); ?></p>
  <?php endif; ?>
</header>

<section>
  <div class="wrap">
    <?php if (have_posts()) : ?>
      <div class="posts-grid">
        <?php while (have_posts()) : the_post(); ?>
          <?php get_template_part('template-parts/card', 'post'); ?>
        <?php endwhile; ?>
      </div>
      <?php la_lignee_pagination(); ?>
    <?php else : ?>
      <p class="lead">Aucun contenu à afficher.</p>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
