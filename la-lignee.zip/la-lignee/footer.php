<?php if (!defined('ABSPATH')) exit; ?>
</main>

<footer class="site-footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <div class="brand-mark">La Lignée<span class="accent"></span></div>
      <p><?php echo esc_html(get_bloginfo('description') ?: 'Cabinet de conseil & stratégie. Nous accompagnons les marques qui veulent grandir avec méthode.'); ?></p>
    </div>

    <div class="footer-col">
      <h5>Cabinet</h5>
      <ul>
        <li><a href="<?php echo esc_url(home_url('/#methode')); ?>">Notre méthode</a></li>
        <li><a href="<?php echo esc_url(home_url('/#poles')); ?>">Nos pôles</a></li>
        <li><a href="<?php echo esc_url(home_url('/#principes')); ?>">Nos principes</a></li>
        <li><a href="<?php echo esc_url(get_post_type_archive_link('realisation') ?: home_url('/realisations')); ?>">Réalisations</a></li>
        <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Journal</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h5>Contact</h5>
      <ul>
        <?php $email = la_lignee_opt('email','contact@lalignee.ci'); ?>
        <?php $phone = la_lignee_opt('phone','+225 00 00 00 00'); ?>
        <?php $addr  = la_lignee_opt('address','Abidjan, Côte d\'Ivoire'); ?>
        <li><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></li>
        <li><a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$phone)); ?>"><?php echo esc_html($phone); ?></a></li>
        <li><?php echo esc_html($addr); ?></li>
      </ul>
    </div>

    <div class="footer-col">
      <h5>Suivre</h5>
      <ul>
        <?php $ig = la_lignee_opt('instagram',''); $li = la_lignee_opt('linkedin',''); ?>
        <?php if ($ig): ?><li><a href="<?php echo esc_url($ig); ?>" target="_blank" rel="noopener">Instagram</a></li><?php endif; ?>
        <?php if ($li): ?><li><a href="<?php echo esc_url($li); ?>" target="_blank" rel="noopener">LinkedIn</a></li><?php endif; ?>
        <li><a href="<?php echo esc_url(home_url('/#contact')); ?>">Nous écrire</a></li>
      </ul>
    </div>
  </div>

  <div class="footer-bottom">
    © <?php echo esc_html(date('Y')); ?> La Lignée · Conseil &amp; stratégie · Abidjan
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
