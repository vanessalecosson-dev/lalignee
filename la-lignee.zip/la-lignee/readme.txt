=== La Lignée ===
Contributors: La Lignée
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Thème WordPress sur-mesure pour le cabinet La Lignée — Conseil & stratégie (Abidjan).

== Installation ==

1. Dans l'admin WordPress, allez dans Apparence > Thèmes > Ajouter > Téléverser un thème.
2. Sélectionnez le fichier « la-lignee.zip » et cliquez sur Installer.
3. Activez le thème.
4. (Recommandé) Allez dans Apparence > Personnaliser :
   - Identité du site : téléversez le logo (fourni par défaut si aucun n'est chargé).
   - La Lignée — Contact : renseignez email, téléphone, adresse, réseaux, et l'email qui recevra les messages du formulaire.
   - La Lignée — Accueil (Hero) : personnalisez la phrase manifeste et les mentions.
5. Réglages > Lecture : définissez « Votre page d'accueil affiche » sur « Vos derniers articles » (par défaut) — la page d'accueil utilise `front-page.php` automatiquement.
   Sinon, créez une Page « Accueil » vide, une Page « Journal » vide, puis sélectionnez-les comme page d'accueil / page des articles.
6. Apparence > Menus : créez un menu et assignez-le à « Menu principal ».

== Sections page d'accueil ==

- Hero manifeste
- Fil « stratégie & donnée »
- Qui nous sommes
- Méthode (triptyque Penser · Déployer · Mesurer)
- Pôle I — Conseil & Stratégie (offres sans prix)
- Pôle II — Digital & Tech (offres sans prix)
- Pôle III — Data & Analyse (offres sans prix)
- Principes de travail
- Derniers articles du journal
- Bloc contact + formulaire (email envoyé via wp_mail)

== Formulaire de contact ==

Le formulaire utilise wp_mail(). Pour une délivrabilité fiable en production, installez un plugin SMTP (WP Mail SMTP, FluentSMTP…) et configurez un expéditeur du domaine du site.
Un champ anti-spam (honeypot) est intégré.

== Crédits ==

Polices : Cormorant Garamond & Jost via Google Fonts.

== v1.1.0 — Réalisations ==

- Nouveau Custom Post Type « Réalisation » (menu Réalisations dans l'admin).
- Taxonomies : Pôle (Conseil & Stratégie, Digital & Tech, Data & Analyse — créés automatiquement) et Secteur.
- Champs projet : Client, Année, Mission (résumé), Lien externe.
- Page listing publique : /realisations (filtrable par pôle, filtre instantané côté client + URL ?pole=slug).
- Page single dédiée avec image de couverture, encart « fiche projet » et réalisations connexes.
- Bloc « Quelques études de cas » ajouté sur la page d'accueil (masqué tant qu'aucune réalisation n'existe).
- Lien « Réalisations » ajouté au menu principal et au pied de page.

Pour publier une étude de cas :
Admin > Réalisations > Ajouter — renseignez titre, contenu, image de couverture, extrait,
puis dans la colonne de droite : Pôle, Secteur, et la fiche projet (client, année, mission, lien).
