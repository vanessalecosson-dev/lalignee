<?php
/**
 * Archive : Réalisations — listing filtrable
 */
if (!defined('ABSPATH')) exit;
get_header();

$active_pole = isset($_GET['pole']) ? sanitize_title(wp_unslash($_GET['pole'])) : '';
$poles = get_terms(array('taxonomy' => 'pole', 'hide_empty' => false));
?>

<header class="page-header">
  <p class="eyebrow">Nos travaux</p>
  <h1>Réalisations &amp; études de cas</h1>
  <p class="lead">Sélection de missions menées avec nos clients — de la pensée à la preuve.</p>
</header>

<section>
  <div class="wrap">

    <?php if (!empty($poles) && !is_wp_error($poles)) : ?>
    <nav class="filter-bar reveal" aria-label="Filtrer par pôle">
      <a href="<?php echo esc_url(get_post_type_archive_link('realisation')); ?>"
         class="filter-chip <?php echo $active_pole === '' ? 'is-active' : ''; ?>"
         data-filter="all">Tous</a>
      <?php foreach ($poles as $term) : ?>
        <a href="<?php echo esc_url(add_query_arg('pole', $term->slug, get_post_type_archive_link('realisation'))); ?>"
           class="filter-chip <?php echo $active_pole === $term->slug ? 'is-active' : ''; ?>"
           data-filter="<?php echo esc_attr($term->slug); ?>">
          <?php echo esc_html($term->name); ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <?php endif; ?>

    <?php
    // Server-side filter when a query string is present
    if ($active_pole !== '') {
        query_posts(array(
            'post_type' => 'realisation',
            'posts_per_page' => 12,
            'paged' => max(1, get_query_var('paged')),
            'tax_query' => array(array(
                'taxonomy' => 'pole', 'field' => 'slug', 'terms' => $active_pole,
            )),
        ));
    }
    ?>

    <?php if (have_posts()) : ?>
      <div class="realisations-grid" id="realisations-grid">
        <?php while (have_posts()) : the_post();
          $post_poles = wp_get_post_terms(get_the_ID(), 'pole', array('fields' => 'slugs'));
          $client = get_post_meta(get_the_ID(), '_ll_client', true);
          $annee  = get_post_meta(get_the_ID(), '_ll_annee', true);
        ?>
          <a class="rea-card reveal" href="<?php the_permalink(); ?>" data-poles="<?php echo esc_attr(implode(' ', $post_poles)); ?>">
            <div class="rea-thumb">
              <?php if (has_post_thumbnail()) : the_post_thumbnail('la-lignee-card', array('alt' => the_title_attribute(array('echo' => false))));
              else : ?><div class="rea-placeholder">La Lignée</div><?php endif; ?>
            </div>
            <div class="rea-body">
              <div class="rea-meta">
                <?php $terms = wp_get_post_terms(get_the_ID(), 'pole');
                if (!empty($terms) && !is_wp_error($terms)) echo esc_html($terms[0]->name);
                if ($annee) echo ' · ' . esc_html($annee); ?>
              </div>
              <h3 class="rea-title"><?php the_title(); ?></h3>
              <?php if ($client) : ?><div class="rea-client"><?php echo esc_html($client); ?></div><?php endif; ?>
              <p class="rea-excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
              <span class="rea-arrow">Voir l'étude →</span>
            </div>
          </a>
        <?php endwhile; ?>
      </div>
      <?php la_lignee_pagination(); ?>
      <?php if ($active_pole !== '') wp_reset_query(); ?>
    <?php else : ?>
      <p class="lead" style="margin-top:40px">Les premières études de cas seront publiées prochainement.</p>
    <?php endif; ?>
  </div>
</section>

<?php get_template_part('template-parts/contact-section'); ?>
<?php get_footer(); ?>
