<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<header class="page-header">
  <p class="eyebrow">Recherche</p>
  <h1>Résultats pour « <?php echo esc_html(get_search_query()); ?> »</h1>
</header>

<section>
  <div class="wrap">
    <?php if (have_posts()) : ?>
      <div class="posts-grid">
        <?php while (have_posts()) : the_post(); ?>
          <?php get_template_part('template-parts/card', 'post'); ?>
        <?php endwhile; ?>
      </div>
      <?php la_lignee_pagination(); ?>
    <?php else : ?>
      <p class="lead">Aucun résultat. Essayez d'autres mots-clés.</p>
      <div style="max-width:520px;margin:40px auto 0"><?php get_search_form(); ?></div>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
