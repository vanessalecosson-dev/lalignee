(function(){
  // Reveal on scroll
  var io = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  },{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){ io.observe(el); });

  // Mobile nav
  var toggle = document.querySelector('.nav-toggle');
  var menu = document.querySelector('.nav-menu');
  if(toggle && menu){
    toggle.addEventListener('click', function(){
      toggle.classList.toggle('open');
      menu.classList.toggle('open');
    });
    menu.querySelectorAll('a').forEach(function(a){
      a.addEventListener('click', function(){ toggle.classList.remove('open'); menu.classList.remove('open'); });
    });
  }

  // Contact form (AJAX)
  var form = document.getElementById('la-lignee-contact-form');
  if(form){
    var refreshCaptcha = function(){
      var tokenInput = form.querySelector('input[name="cap_token"]');
      var answerInput = form.querySelector('input[name="cap_answer"]');
      var label = answerInput ? form.querySelector('label[for="'+answerInput.id+'"]') : null;
      if(!tokenInput || !label) return;
      fetch(window.LALIGNEE.ajaxUrl + '?action=la_lignee_captcha', {credentials:'same-origin'})
        .then(function(r){ return r.json(); })
        .then(function(j){
          if(j && j.success && j.data){
            tokenInput.value = j.data.token;
            label.childNodes[0].nodeValue = j.data.question + ' ';
            if(answerInput) answerInput.value = '';
          }
        }).catch(function(){});
    };

    form.addEventListener('submit', function(e){
      e.preventDefault();
      var msg = form.querySelector('.form-msg');
      var btn = form.querySelector('button[type="submit"]');
      msg.className = 'form-msg';
      msg.textContent = 'Envoi en cours…';
      if(btn) btn.disabled = true;
      var data = new FormData(form);
      data.append('action','la_lignee_contact');
      fetch(window.LALIGNEE.ajaxUrl, {method:'POST', body:data, credentials:'same-origin'})
        .then(function(r){ return r.json(); })
        .then(function(j){
          if(j && j.success){
            msg.className = 'form-msg success';
            msg.textContent = j.data && j.data.message ? j.data.message : 'Merci, votre message a bien été envoyé.';
            form.reset();
            var started = form.querySelector('input[name="form_started"]');
            if(started) started.value = Math.floor(Date.now()/1000);
          } else {
            msg.className = 'form-msg error';
            msg.textContent = (j && j.data && j.data.message) ? j.data.message : 'Une erreur est survenue. Veuillez réessayer.';
          }
          refreshCaptcha();
        })
        .catch(function(){
          msg.className = 'form-msg error';
          msg.textContent = 'Une erreur est survenue. Veuillez réessayer.';
          refreshCaptcha();
        })
        .finally(function(){ if(btn) btn.disabled = false; });
    });
  }
})();

// Filtre client-side des réalisations (si présent sans query string)
(function(){
  var chips = document.querySelectorAll('.filter-bar .filter-chip');
  var grid  = document.getElementById('realisations-grid');
  if(!chips.length || !grid) return;
  // Si la page a été chargée avec ?pole=... on laisse le rendu serveur.
  if(window.location.search.indexOf('pole=') !== -1) return;

  chips.forEach(function(chip){
    chip.addEventListener('click', function(e){
      e.preventDefault();
      var filter = chip.getAttribute('data-filter');
      chips.forEach(function(c){ c.classList.remove('is-active'); });
      chip.classList.add('is-active');
      grid.querySelectorAll('.rea-card').forEach(function(card){
        var poles = (card.getAttribute('data-poles') || '').split(' ');
        if(filter === 'all' || poles.indexOf(filter) !== -1){
          card.classList.remove('is-hidden');
        } else {
          card.classList.add('is-hidden');
        }
      });
    });
  });
})();

/* ---------- FAQ : filtre par thème ---------- */
(function(){
  var chips = document.querySelectorAll('.faq-filter .faq-chip');
  var list  = document.getElementById('faq-list');
  if(!chips.length || !list) return;
  var items = list.querySelectorAll('.faq-item');
  var empty = document.querySelector('.faq-empty');

  function applyFilter(filter){
    var visible = 0;
    items.forEach(function(item){
      var themes = (item.getAttribute('data-themes') || '').split(' ');
      var show = (filter === 'all') || themes.indexOf(filter) !== -1;
      item.classList.toggle('is-hidden', !show);
      if(show) visible++;
      // Referme les questions ouvertes en dehors du filtre
      if(!show){
        var d = item.querySelector('details');
        if(d) d.open = false;
      }
    });
    if(empty) empty.hidden = visible !== 0;
  }

  chips.forEach(function(chip){
    chip.addEventListener('click', function(){
      chips.forEach(function(c){ c.classList.remove('is-active'); });
      chip.classList.add('is-active');
      applyFilter(chip.getAttribute('data-faq-filter') || 'all');
    });
  });
})();
