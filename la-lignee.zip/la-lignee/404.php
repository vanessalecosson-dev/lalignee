<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<section class="notfound">
  <div>
    <h1>404</h1>
    <p>La page que vous cherchez s'est égarée de la lignée.</p>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-gold" style="background:var(--gold);color:var(--ink)">Retour à l'accueil</a>
  </div>
</section>

<?php get_footer(); ?>
