<?php
/**
 * Archive : taxonomie pôle (utilise le même rendu que archive-realisation.php)
 */
if (!defined('ABSPATH')) exit;
get_header();
$term = get_queried_object();
?>

<header class="page-header">
  <p class="eyebrow">Réalisations · Pôle</p>
  <h1><?php echo esc_html($term->name); ?></h1>
  <?php if (!empty($term->description)) : ?><p class="lead"><?php echo esc_html($term->description); ?></p><?php endif; ?>
</header>

<section>
  <div class="wrap">
    <nav class="filter-bar" aria-label="Filtrer par pôle">
      <a href="<?php echo esc_url(get_post_type_archive_link('realisation')); ?>" class="filter-chip">Tous</a>
      <?php foreach (get_terms(array('taxonomy' => 'pole', 'hide_empty' => false)) as $t) : ?>
        <a href="<?php echo esc_url(get_term_link($t)); ?>"
           class="filter-chip <?php echo $t->term_id === $term->term_id ? 'is-active' : ''; ?>">
          <?php echo esc_html($t->name); ?>
        </a>
      <?php endforeach; ?>
    </nav>

    <?php if (have_posts()) : ?>
      <div class="realisations-grid">
        <?php while (have_posts()) : the_post();
          $client = get_post_meta(get_the_ID(), '_ll_client', true);
          $annee  = get_post_meta(get_the_ID(), '_ll_annee', true);
        ?>
          <a class="rea-card" href="<?php the_permalink(); ?>">
            <div class="rea-thumb">
              <?php if (has_post_thumbnail()) the_post_thumbnail('la-lignee-card');
              else echo '<div class="rea-placeholder">La Lignée</div>'; ?>
            </div>
            <div class="rea-body">
              <div class="rea-meta"><?php echo esc_html($term->name); if ($annee) echo ' · ' . esc_html($annee); ?></div>
              <h3 class="rea-title"><?php the_title(); ?></h3>
              <?php if ($client) : ?><div class="rea-client"><?php echo esc_html($client); ?></div><?php endif; ?>
              <p class="rea-excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
            </div>
          </a>
        <?php endwhile; ?>
      </div>
      <?php la_lignee_pagination(); ?>
    <?php else : ?>
      <p class="lead">Aucune réalisation dans ce pôle pour l'instant.</p>
    <?php endif; ?>
  </div>
</section>

<?php get_template_part('template-parts/contact-section'); ?>
<?php get_footer(); ?>
