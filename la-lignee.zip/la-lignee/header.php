<?php if (!defined('ABSPATH')) exit; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php if (function_exists('wp_body_open')) wp_body_open(); ?>

<a class="screen-reader-text" href="#site-content"><?php esc_html_e('Aller au contenu', 'la-lignee'); ?></a>

<header class="site-header">
  <div class="nav">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-brand" rel="home">
      <?php if (has_custom_logo()) : ?>
        <?php the_custom_logo(); ?>
      <?php else : ?>
        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo.png'); ?>" alt="<?php bloginfo('name'); ?>">
      <?php endif; ?>
    </a>

    <button class="nav-toggle" aria-label="<?php esc_attr_e('Ouvrir le menu', 'la-lignee'); ?>" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

    <?php if (has_nav_menu('primary')) :
      wp_nav_menu(array(
        'theme_location' => 'primary',
        'menu_class'     => 'nav-menu',
        'container'      => false,
        'depth'          => 1,
      ));
    else : ?>
      <ul class="nav-menu">
        <li><a href="<?php echo esc_url(home_url('/#methode')); ?>">Méthode</a></li>
        <li><a href="<?php echo esc_url(home_url('/#poles')); ?>">Pôles</a></li>
        <li><a href="<?php echo esc_url(get_post_type_archive_link('realisation') ?: home_url('/realisations')); ?>">Réalisations</a></li>
        <li><a href="<?php echo esc_url(home_url('/#principes')); ?>">Principes</a></li>
        <li><a href="<?php echo esc_url(home_url('/blog')); ?>">Journal</a></li>
        <li><a href="<?php echo esc_url(home_url('/#faq')); ?>">FAQ</a></li>
        <li><a href="<?php echo esc_url(home_url('/#contact')); ?>">Contact</a></li>
      </ul>
    <?php endif; ?>

    <a href="<?php echo esc_url(home_url('/#contact')); ?>" class="nav-cta">Entrons en lignée</a>
  </div>
</header>

<main id="site-content">
