<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
<header class="page-header">
  <p class="eyebrow">La Lignée</p>
  <h1><?php the_title(); ?></h1>
</header>

<article class="single-post-content">
  <div class="content"><?php the_content(); ?></div>
</article>
<?php endwhile; ?>

<?php get_footer(); ?>
