<?php
/**
 * Custom Post Type : Réalisations (études de cas)
 */
if (!defined('ABSPATH')) exit;

/* ---------- CPT ---------- */
function la_lignee_register_realisation() {
    $labels = array(
        'name'                  => 'Réalisations',
        'singular_name'         => 'Réalisation',
        'menu_name'             => 'Réalisations',
        'name_admin_bar'        => 'Réalisation',
        'add_new'               => 'Ajouter',
        'add_new_item'          => 'Ajouter une réalisation',
        'new_item'              => 'Nouvelle réalisation',
        'edit_item'             => 'Modifier la réalisation',
        'view_item'             => 'Voir la réalisation',
        'all_items'             => 'Toutes les réalisations',
        'search_items'          => 'Rechercher',
        'not_found'             => 'Aucune réalisation trouvée.',
        'not_found_in_trash'    => 'Aucune réalisation dans la corbeille.',
        'featured_image'        => 'Image de couverture',
        'set_featured_image'    => 'Définir la couverture',
        'archives'              => 'Toutes les réalisations',
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => 'realisations',
        'rewrite'            => array('slug' => 'realisations', 'with_front' => false),
        'menu_icon'          => 'dashicons-portfolio',
        'menu_position'      => 20,
        'supports'           => array('title','editor','thumbnail','excerpt','revisions','custom-fields'),
        'show_in_rest'       => true,
        'hierarchical'       => false,
    );
    register_post_type('realisation', $args);
}
add_action('init', 'la_lignee_register_realisation');

/* ---------- Taxonomie : Pôle ---------- */
function la_lignee_register_pole_taxonomy() {
    $labels = array(
        'name'          => 'Pôles',
        'singular_name' => 'Pôle',
        'search_items'  => 'Rechercher un pôle',
        'all_items'     => 'Tous les pôles',
        'edit_item'     => 'Modifier le pôle',
        'update_item'   => 'Mettre à jour',
        'add_new_item'  => 'Ajouter un pôle',
        'new_item_name' => 'Nom du pôle',
        'menu_name'     => 'Pôles',
    );
    register_taxonomy('pole', array('realisation'), array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest'      => true,
        'rewrite'           => array('slug' => 'pole', 'with_front' => false),
    ));

    // Taxonomie secondaire : Client / Secteur
    register_taxonomy('secteur', array('realisation'), array(
        'hierarchical'      => false,
        'labels'            => array(
            'name'          => 'Secteurs',
            'singular_name' => 'Secteur',
            'menu_name'     => 'Secteurs',
            'all_items'     => 'Tous les secteurs',
            'add_new_item'  => 'Ajouter un secteur',
            'new_item_name' => 'Nom du secteur',
        ),
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'show_in_rest'      => true,
        'rewrite'           => array('slug' => 'secteur', 'with_front' => false),
    ));
}
add_action('init', 'la_lignee_register_pole_taxonomy');

/* ---------- Termes par défaut à l'activation ---------- */
function la_lignee_seed_poles() {
    $poles = array(
        'conseil-strategie' => 'Conseil & Stratégie',
        'digital-tech'      => 'Digital & Tech',
        'data-analyse'      => 'Data & Analyse',
    );
    foreach ($poles as $slug => $name) {
        if (!term_exists($slug, 'pole')) {
            wp_insert_term($name, 'pole', array('slug' => $slug));
        }
    }
}
add_action('init', 'la_lignee_seed_poles', 20);

/* ---------- Métadonnées : client, année, résumé, mission ---------- */
function la_lignee_realisation_meta_box() {
    add_meta_box(
        'la_lignee_realisation_meta',
        'Fiche projet',
        'la_lignee_realisation_meta_render',
        'realisation',
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'la_lignee_realisation_meta_box');

function la_lignee_realisation_meta_render($post) {
    wp_nonce_field('la_lignee_realisation_meta', 'la_lignee_realisation_meta_nonce');
    $client  = get_post_meta($post->ID, '_ll_client', true);
    $annee   = get_post_meta($post->ID, '_ll_annee', true);
    $mission = get_post_meta($post->ID, '_ll_mission', true);
    $lien    = get_post_meta($post->ID, '_ll_lien', true);
    ?>
    <p><label><strong>Client</strong><br>
      <input type="text" name="ll_client" value="<?php echo esc_attr($client); ?>" style="width:100%"></label></p>
    <p><label><strong>Année</strong><br>
      <input type="text" name="ll_annee" value="<?php echo esc_attr($annee); ?>" style="width:100%" placeholder="2025"></label></p>
    <p><label><strong>Mission (résumé)</strong><br>
      <textarea name="ll_mission" rows="3" style="width:100%"><?php echo esc_textarea($mission); ?></textarea></label></p>
    <p><label><strong>Lien externe (facultatif)</strong><br>
      <input type="url" name="ll_lien" value="<?php echo esc_attr($lien); ?>" style="width:100%" placeholder="https://…"></label></p>
    <?php
}

function la_lignee_realisation_meta_save($post_id) {
    if (!isset($_POST['la_lignee_realisation_meta_nonce'])) return;
    if (!wp_verify_nonce($_POST['la_lignee_realisation_meta_nonce'], 'la_lignee_realisation_meta')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $fields = array('ll_client' => '_ll_client', 'll_annee' => '_ll_annee', 'll_mission' => '_ll_mission', 'll_lien' => '_ll_lien');
    foreach ($fields as $post_key => $meta_key) {
        if (isset($_POST[$post_key])) {
            $val = wp_unslash($_POST[$post_key]);
            if ($post_key === 'll_lien')       $val = esc_url_raw($val);
            elseif ($post_key === 'll_mission') $val = sanitize_textarea_field($val);
            else                                 $val = sanitize_text_field($val);
            update_post_meta($post_id, $meta_key, $val);
        }
    }
}
add_action('save_post_realisation', 'la_lignee_realisation_meta_save');

/* ---------- Flush rewrites à l'activation du thème ---------- */
function la_lignee_theme_activation() {
    la_lignee_register_realisation();
    la_lignee_register_pole_taxonomy();
    la_lignee_seed_poles();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'la_lignee_theme_activation');
