<?php
/**
 * La Lignée — Traitement du formulaire de contact
 *  - Nonce
 *  - Honeypot
 *  - Time-trap (délai minimum)
 *  - Question mathématique (captcha léger)
 *  - Envoi via wp_mail()
 *  - Sauvegarde optionnelle en CPT "Messages"
 */
if (!defined('ABSPATH')) exit;

/* ---------- CPT: Messages (backup + historique) ---------- */
function la_lignee_register_message_cpt() {
    register_post_type('la_message', array(
        'labels' => array(
            'name'          => __('Messages', 'la-lignee'),
            'singular_name' => __('Message', 'la-lignee'),
            'menu_name'     => __('Messages', 'la-lignee'),
            'all_items'     => __('Tous les messages', 'la-lignee'),
        ),
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => 'la-lignee-contact',
        'capability_type'     => 'post',
        'capabilities'        => array('create_posts' => 'do_not_allow'),
        'map_meta_cap'        => true,
        'supports'            => array('title', 'editor', 'custom-fields'),
        'has_archive'         => false,
        'rewrite'             => false,
        'exclude_from_search' => true,
    ));
}
add_action('init', 'la_lignee_register_message_cpt');

/* ---------- Génération d'un défi captcha (server-side) ---------- */
function la_lignee_captcha_challenge() {
    $a = wp_rand(1, 9);
    $b = wp_rand(1, 9);
    $token = wp_generate_password(20, false, false);
    set_transient('la_lignee_cap_' . $token, $a + $b, 30 * MINUTE_IN_SECONDS);
    return array(
        'token'    => $token,
        'question' => sprintf('Combien font %d + %d ?', $a, $b),
    );
}

function la_lignee_captcha_check($token, $answer) {
    if (!$token) return false;
    $expected = get_transient('la_lignee_cap_' . $token);
    delete_transient('la_lignee_cap_' . $token);
    if ($expected === false) return false;
    return (int) $answer === (int) $expected;
}

/* ---------- Handler AJAX ---------- */
function la_lignee_handle_contact() {
    $o = la_lignee_contact_get_options();

    // 1) Nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'la_lignee_contact')) {
        wp_send_json_error(array('message' => 'Session expirée. Veuillez recharger la page et réessayer.'));
    }

    // 2) Honeypot — silence radio pour ne pas informer le bot
    $hp = isset($_POST['website']) ? trim(wp_unslash($_POST['website'])) : '';
    if ($hp !== '') {
        wp_send_json_success(array('message' => $o['success_message']));
    }

    // 3) Time-trap
    $started = isset($_POST['form_started']) ? absint($_POST['form_started']) : 0;
    $min     = max(0, (int) $o['antispam_time']);
    if ($min > 0 && (time() - $started) < $min) {
        wp_send_json_error(array('message' => 'Merci de patienter quelques instants avant d\'envoyer votre message.'));
    }

    // 4) Captcha mathématique
    if (!empty($o['antispam_math'])) {
        $token  = isset($_POST['cap_token']) ? sanitize_text_field(wp_unslash($_POST['cap_token'])) : '';
        $answer = isset($_POST['cap_answer']) ? sanitize_text_field(wp_unslash($_POST['cap_answer'])) : '';
        if (!la_lignee_captcha_check($token, $answer)) {
            wp_send_json_error(array('message' => 'Réponse à la question anti-spam incorrecte. Merci de réessayer.'));
        }
    }

    // 5) Champs
    $name    = isset($_POST['nom']) ? sanitize_text_field(wp_unslash($_POST['nom'])) : '';
    $email   = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
    $company = isset($_POST['entreprise']) ? sanitize_text_field(wp_unslash($_POST['entreprise'])) : '';
    $pole    = isset($_POST['pole']) ? sanitize_text_field(wp_unslash($_POST['pole'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';

    if (!$name || !$email || !$message || !is_email($email)) {
        wp_send_json_error(array('message' => 'Merci de renseigner un nom, un email valide et un message.'));
    }
    if (strlen($message) < 10) {
        wp_send_json_error(array('message' => 'Votre message est trop court. Merci de préciser votre demande.'));
    }
    if (strlen($message) > 5000) {
        wp_send_json_error(array('message' => 'Votre message est trop long (5000 caractères maximum).'));
    }

    // 6) Sauvegarde (optionnelle)
    if (!empty($o['store_messages'])) {
        $post_id = wp_insert_post(array(
            'post_type'    => 'la_message',
            'post_status'  => 'private',
            'post_title'   => sprintf('%s — %s', $name, wp_date('d/m/Y H:i')),
            'post_content' => $message,
            'meta_input'   => array(
                '_lg_email'      => $email,
                '_lg_entreprise' => $company,
                '_lg_pole'       => $pole,
                '_lg_ip'         => la_lignee_client_ip(),
                '_lg_ua'         => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            ),
        ), true);
        unset($post_id);
    }

    // 7) Envoi email
    $to = (!empty($o['to_email']) && is_email($o['to_email'])) ? $o['to_email'] : get_option('admin_email');
    $subject = trim($o['subject_prefix'] . ' Nouveau message — ' . $name);

    $body  = "Nom : {$name}\n";
    $body .= "Email : {$email}\n";
    if ($company) $body .= "Entreprise : {$company}\n";
    if ($pole)    $body .= "Pôle : {$pole}\n";
    $body .= "\nMessage :\n{$message}\n";
    $body .= "\n---\nEnvoyé depuis " . home_url() . "\n";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'Reply-To: ' . $name . ' <' . $email . '>',
    );
    if (!empty($o['cc_email'])) {
        foreach (array_filter(array_map('trim', explode(',', $o['cc_email']))) as $cc) {
            if (is_email($cc)) $headers[] = 'Cc: ' . $cc;
        }
    }

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(array('message' => $o['success_message']));
    } else {
        wp_send_json_error(array('message' => "Le message n'a pas pu être envoyé. Merci d'écrire directement à " . antispambot($to) . '.'));
    }
}
add_action('wp_ajax_la_lignee_contact', 'la_lignee_handle_contact');
add_action('wp_ajax_nopriv_la_lignee_contact', 'la_lignee_handle_contact');

/* ---------- Endpoint AJAX : rafraîchir le captcha ---------- */
function la_lignee_ajax_captcha() {
    wp_send_json_success(la_lignee_captcha_challenge());
}
add_action('wp_ajax_la_lignee_captcha', 'la_lignee_ajax_captcha');
add_action('wp_ajax_nopriv_la_lignee_captcha', 'la_lignee_ajax_captcha');

/* ---------- Utilitaire IP ---------- */
function la_lignee_client_ip() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
    return $ip;
}

/* ---------- Colonnes admin pour les messages ---------- */
function la_lignee_message_columns($cols) {
    $new = array(
        'cb'          => $cols['cb'],
        'title'       => __('Contact', 'la-lignee'),
        'lg_email'    => __('Email', 'la-lignee'),
        'lg_pole'     => __('Pôle', 'la-lignee'),
        'lg_ip'       => __('IP', 'la-lignee'),
        'date'        => __('Reçu le', 'la-lignee'),
    );
    return $new;
}
add_filter('manage_la_message_posts_columns', 'la_lignee_message_columns');

function la_lignee_message_columns_content($col, $post_id) {
    switch ($col) {
        case 'lg_email': echo esc_html(get_post_meta($post_id, '_lg_email', true)); break;
        case 'lg_pole':  echo esc_html(get_post_meta($post_id, '_lg_pole', true)); break;
        case 'lg_ip':    echo esc_html(get_post_meta($post_id, '_lg_ip', true)); break;
    }
}
add_action('manage_la_message_posts_custom_column', 'la_lignee_message_columns_content', 10, 2);
