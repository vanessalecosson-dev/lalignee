<?php
/**
 * La Lignée — Réglages Contact & Email (admin)
 * Ajoute une page d'administration pour :
 *   - Configurer les destinataires du formulaire de contact
 *   - Configurer l'envoi via wp_mail() (SMTP)
 *   - Régler les options anti-spam
 */
if (!defined('ABSPATH')) exit;

/* ---------- Enregistrement des options ---------- */
function la_lignee_contact_default_options() {
    return array(
        // Destinataires & expéditeur
        'to_email'        => get_option('admin_email'),
        'cc_email'        => '',
        'from_name'       => get_bloginfo('name'),
        'from_email'      => get_option('admin_email'),
        'subject_prefix'  => '[La Lignée]',
        'success_message' => 'Merci, votre message a bien été envoyé. Nous revenons vers vous très vite.',

        // SMTP
        'smtp_enabled'    => 0,
        'smtp_host'       => '',
        'smtp_port'       => 587,
        'smtp_secure'     => 'tls', // '', 'ssl', 'tls'
        'smtp_auth'       => 1,
        'smtp_user'       => '',
        'smtp_pass'       => '',

        // Anti-spam
        'antispam_time'   => 3,   // délai minimum entre chargement et envoi (secondes)
        'antispam_math'   => 1,   // question mathématique
        'store_messages'  => 1,   // sauvegarder les messages en base
    );
}

function la_lignee_contact_get_options() {
    $opts = get_option('la_lignee_contact_options', array());
    return wp_parse_args($opts, la_lignee_contact_default_options());
}

function la_lignee_contact_register_settings() {
    register_setting('la_lignee_contact_group', 'la_lignee_contact_options', array(
        'type'              => 'array',
        'sanitize_callback' => 'la_lignee_contact_sanitize_options',
        'default'           => la_lignee_contact_default_options(),
    ));
}
add_action('admin_init', 'la_lignee_contact_register_settings');

function la_lignee_contact_sanitize_options($input) {
    $d = la_lignee_contact_default_options();
    $out = array();

    $out['to_email']        = (isset($input['to_email']) && is_email($input['to_email'])) ? sanitize_email($input['to_email']) : $d['to_email'];
    $out['cc_email']        = isset($input['cc_email']) ? implode(',', array_filter(array_map('sanitize_email', array_map('trim', explode(',', $input['cc_email']))))) : '';
    $out['from_name']       = isset($input['from_name']) ? sanitize_text_field($input['from_name']) : $d['from_name'];
    $out['from_email']      = (isset($input['from_email']) && is_email($input['from_email'])) ? sanitize_email($input['from_email']) : $d['from_email'];
    $out['subject_prefix']  = isset($input['subject_prefix']) ? sanitize_text_field($input['subject_prefix']) : $d['subject_prefix'];
    $out['success_message'] = isset($input['success_message']) ? sanitize_textarea_field($input['success_message']) : $d['success_message'];

    $out['smtp_enabled']    = !empty($input['smtp_enabled']) ? 1 : 0;
    $out['smtp_host']       = isset($input['smtp_host']) ? sanitize_text_field($input['smtp_host']) : '';
    $out['smtp_port']       = isset($input['smtp_port']) ? absint($input['smtp_port']) : 587;
    $secure                 = isset($input['smtp_secure']) ? strtolower(sanitize_text_field($input['smtp_secure'])) : 'tls';
    $out['smtp_secure']     = in_array($secure, array('', 'ssl', 'tls'), true) ? $secure : 'tls';
    $out['smtp_auth']       = !empty($input['smtp_auth']) ? 1 : 0;
    $out['smtp_user']       = isset($input['smtp_user']) ? sanitize_text_field($input['smtp_user']) : '';

    // Mot de passe : ne pas écraser si champ laissé vide
    $existing = get_option('la_lignee_contact_options', array());
    if (isset($input['smtp_pass']) && $input['smtp_pass'] !== '') {
        $out['smtp_pass'] = (string) $input['smtp_pass'];
    } else {
        $out['smtp_pass'] = isset($existing['smtp_pass']) ? (string) $existing['smtp_pass'] : '';
    }

    $out['antispam_time']  = isset($input['antispam_time']) ? max(0, absint($input['antispam_time'])) : 3;
    $out['antispam_math']  = !empty($input['antispam_math']) ? 1 : 0;
    $out['store_messages'] = !empty($input['store_messages']) ? 1 : 0;

    return $out;
}

/* ---------- Page d'administration ---------- */
function la_lignee_contact_admin_menu() {
    add_menu_page(
        __('La Lignée — Contact', 'la-lignee'),
        __('La Lignée', 'la-lignee'),
        'manage_options',
        'la-lignee-contact',
        'la_lignee_contact_render_page',
        'dashicons-email-alt',
        58
    );
    add_submenu_page(
        'la-lignee-contact',
        __('Réglages Contact & Email', 'la-lignee'),
        __('Réglages', 'la-lignee'),
        'manage_options',
        'la-lignee-contact',
        'la_lignee_contact_render_page'
    );
}
add_action('admin_menu', 'la_lignee_contact_admin_menu');

function la_lignee_contact_render_page() {
    if (!current_user_can('manage_options')) return;
    $o = la_lignee_contact_get_options();

    // Envoi d'un email de test
    $test_notice = '';
    if (isset($_POST['la_lignee_send_test']) && check_admin_referer('la_lignee_send_test')) {
        $to = isset($_POST['test_to']) ? sanitize_email(wp_unslash($_POST['test_to'])) : $o['to_email'];
        if (!is_email($to)) {
            $test_notice = '<div class="notice notice-error"><p>Adresse de test invalide.</p></div>';
        } else {
            $subject = trim($o['subject_prefix'] . ' Test d\'envoi wp_mail()');
            $body    = "Ceci est un email de test envoyé depuis le thème La Lignée.\n\nSite : " . home_url() . "\nDate : " . current_time('mysql');
            $ok = wp_mail($to, $subject, $body);
            $test_notice = $ok
                ? '<div class="notice notice-success"><p>Email de test envoyé à <strong>' . esc_html($to) . '</strong>.</p></div>'
                : '<div class="notice notice-error"><p>Échec de l\'envoi. Vérifiez la configuration SMTP.</p></div>';
        }
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('La Lignée — Contact & Email', 'la-lignee'); ?></h1>
        <?php echo $test_notice; // phpcs:ignore ?>
        <p class="description">Configurez les destinataires du formulaire de contact, l'expéditeur, l'envoi via SMTP (utilisé par <code>wp_mail()</code>) et les protections anti-spam.</p>

        <form method="post" action="options.php">
            <?php settings_fields('la_lignee_contact_group'); ?>

            <h2 class="title">Formulaire de contact</h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="to_email">Destinataire (À)</label></th>
                    <td><input type="email" id="to_email" name="la_lignee_contact_options[to_email]" value="<?php echo esc_attr($o['to_email']); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="cc_email">Copie (CC)</label></th>
                    <td>
                        <input type="text" id="cc_email" name="la_lignee_contact_options[cc_email]" value="<?php echo esc_attr($o['cc_email']); ?>" class="regular-text">
                        <p class="description">Séparez plusieurs adresses par une virgule.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="from_name">Nom de l'expéditeur</label></th>
                    <td><input type="text" id="from_name" name="la_lignee_contact_options[from_name]" value="<?php echo esc_attr($o['from_name']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="from_email">Email de l'expéditeur</label></th>
                    <td>
                        <input type="email" id="from_email" name="la_lignee_contact_options[from_email]" value="<?php echo esc_attr($o['from_email']); ?>" class="regular-text">
                        <p class="description">Idéalement une adresse de votre domaine (ex. contact@votre-domaine.com).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="subject_prefix">Préfixe du sujet</label></th>
                    <td><input type="text" id="subject_prefix" name="la_lignee_contact_options[subject_prefix]" value="<?php echo esc_attr($o['subject_prefix']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="success_message">Message de confirmation</label></th>
                    <td><textarea id="success_message" name="la_lignee_contact_options[success_message]" rows="2" class="large-text"><?php echo esc_textarea($o['success_message']); ?></textarea></td>
                </tr>
            </table>

            <h2 class="title">Envoi via SMTP (wp_mail)</h2>
            <p class="description">Activez cette option pour router <code>wp_mail()</code> vers un serveur SMTP de votre choix (recommandé pour la délivrabilité).</p>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Activer SMTP</th>
                    <td><label><input type="checkbox" name="la_lignee_contact_options[smtp_enabled]" value="1" <?php checked($o['smtp_enabled'], 1); ?>> Router les emails via SMTP</label></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_host">Hôte SMTP</label></th>
                    <td><input type="text" id="smtp_host" name="la_lignee_contact_options[smtp_host]" value="<?php echo esc_attr($o['smtp_host']); ?>" class="regular-text" placeholder="smtp.exemple.com"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_port">Port</label></th>
                    <td><input type="number" id="smtp_port" name="la_lignee_contact_options[smtp_port]" value="<?php echo esc_attr($o['smtp_port']); ?>" class="small-text" min="1" max="65535"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_secure">Chiffrement</label></th>
                    <td>
                        <select id="smtp_secure" name="la_lignee_contact_options[smtp_secure]">
                            <option value="tls" <?php selected($o['smtp_secure'], 'tls'); ?>>TLS (port 587)</option>
                            <option value="ssl" <?php selected($o['smtp_secure'], 'ssl'); ?>>SSL (port 465)</option>
                            <option value=""    <?php selected($o['smtp_secure'], ''); ?>>Aucun</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Authentification</th>
                    <td><label><input type="checkbox" name="la_lignee_contact_options[smtp_auth]" value="1" <?php checked($o['smtp_auth'], 1); ?>> Le serveur requiert une authentification</label></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_user">Nom d'utilisateur SMTP</label></th>
                    <td><input type="text" id="smtp_user" name="la_lignee_contact_options[smtp_user]" value="<?php echo esc_attr($o['smtp_user']); ?>" class="regular-text" autocomplete="off"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="smtp_pass">Mot de passe SMTP</label></th>
                    <td>
                        <input type="password" id="smtp_pass" name="la_lignee_contact_options[smtp_pass]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo !empty($o['smtp_pass']) ? '••••••••••••' : ''; ?>">
                        <p class="description">Laissez vide pour conserver le mot de passe enregistré.</p>
                    </td>
                </tr>
            </table>

            <h2 class="title">Anti-spam</h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="antispam_time">Délai minimum</label></th>
                    <td>
                        <input type="number" id="antispam_time" name="la_lignee_contact_options[antispam_time]" value="<?php echo esc_attr($o['antispam_time']); ?>" class="small-text" min="0" max="60"> secondes
                        <p class="description">Empêche les envois quasi-instantanés effectués par des robots.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Question mathématique</th>
                    <td><label><input type="checkbox" name="la_lignee_contact_options[antispam_math]" value="1" <?php checked($o['antispam_math'], 1); ?>> Afficher une petite addition à résoudre</label></td>
                </tr>
                <tr>
                    <th scope="row">Historique</th>
                    <td><label><input type="checkbox" name="la_lignee_contact_options[store_messages]" value="1" <?php checked($o['store_messages'], 1); ?>> Enregistrer les messages dans <em>La Lignée &rsaquo; Messages</em></label></td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>

        <hr>
        <h2>Envoyer un email de test</h2>
        <form method="post">
            <?php wp_nonce_field('la_lignee_send_test'); ?>
            <input type="hidden" name="la_lignee_send_test" value="1">
            <input type="email" name="test_to" value="<?php echo esc_attr($o['to_email']); ?>" class="regular-text" required>
            <?php submit_button('Envoyer un test', 'secondary', 'submit', false); ?>
        </form>
    </div>
    <?php
}

/* ---------- Application des réglages SMTP à wp_mail() ---------- */
function la_lignee_configure_phpmailer($phpmailer) {
    $o = la_lignee_contact_get_options();
    if (empty($o['smtp_enabled']) || empty($o['smtp_host'])) return;

    $phpmailer->isSMTP();
    $phpmailer->Host       = $o['smtp_host'];
    $phpmailer->Port       = (int) $o['smtp_port'];
    $phpmailer->SMTPSecure = $o['smtp_secure']; // '', 'ssl', 'tls'
    $phpmailer->SMTPAuth   = (bool) $o['smtp_auth'];
    if ($o['smtp_auth']) {
        $phpmailer->Username = $o['smtp_user'];
        $phpmailer->Password = $o['smtp_pass'];
    }
    $phpmailer->CharSet = 'UTF-8';
}
add_action('phpmailer_init', 'la_lignee_configure_phpmailer');

function la_lignee_mail_from($email) {
    $o = la_lignee_contact_get_options();
    return (!empty($o['from_email']) && is_email($o['from_email'])) ? $o['from_email'] : $email;
}
add_filter('wp_mail_from', 'la_lignee_mail_from');

function la_lignee_mail_from_name($name) {
    $o = la_lignee_contact_get_options();
    return !empty($o['from_name']) ? $o['from_name'] : $name;
}
add_filter('wp_mail_from_name', 'la_lignee_mail_from_name');
