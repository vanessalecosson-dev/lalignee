<?php
/**
 * La Lignée — CPT FAQ + taxonomie "Thème FAQ"
 */
if (!defined('ABSPATH')) exit;

function la_lignee_register_faq() {
    register_post_type('la_faq', array(
        'labels' => array(
            'name'          => __('FAQ', 'la-lignee'),
            'singular_name' => __('Question', 'la-lignee'),
            'menu_name'     => __('FAQ', 'la-lignee'),
            'add_new'       => __('Ajouter une question', 'la-lignee'),
            'add_new_item'  => __('Nouvelle question', 'la-lignee'),
            'edit_item'     => __('Modifier la question', 'la-lignee'),
            'all_items'     => __('Toutes les questions', 'la-lignee'),
            'search_items'  => __('Rechercher une question', 'la-lignee'),
        ),
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'menu_icon'    => 'dashicons-editor-help',
        'menu_position'=> 26,
        'supports'     => array('title', 'editor', 'page-attributes'),
        'has_archive'  => false,
        'rewrite'      => false,
        'show_in_rest' => true,
    ));

    register_taxonomy('faq_theme', 'la_faq', array(
        'labels' => array(
            'name'          => __('Thèmes FAQ', 'la-lignee'),
            'singular_name' => __('Thème', 'la-lignee'),
            'menu_name'     => __('Thèmes', 'la-lignee'),
            'all_items'     => __('Tous les thèmes', 'la-lignee'),
            'add_new_item'  => __('Ajouter un thème', 'la-lignee'),
        ),
        'hierarchical' => true,
        'public'       => false,
        'show_ui'      => true,
        'show_admin_column' => true,
        'show_in_rest' => true,
        'rewrite'      => false,
    ));
}
add_action('init', 'la_lignee_register_faq');

/* ---------- Contenu par défaut à la première activation ---------- */
function la_lignee_seed_faq() {
    if (get_option('la_lignee_faq_seeded')) return;

    $themes = array(
        'conseil'  => 'Conseil & Stratégie',
        'digital'  => 'Digital & Tech',
        'data'     => 'Data & Analyse',
        'general'  => 'Général',
    );
    $term_ids = array();
    foreach ($themes as $slug => $name) {
        $t = term_exists($slug, 'faq_theme');
        if (!$t) $t = wp_insert_term($name, 'faq_theme', array('slug' => $slug));
        if (!is_wp_error($t)) $term_ids[$slug] = is_array($t) ? (int)$t['term_id'] : (int)$t;
    }

    $seed = array(
        array('general', 'Comment savoir quel pôle correspond à mon besoin ?',
              "Le plus simple est d'écrire quelques lignes sur votre objectif. Nous vous orientons en 48 h vers le pôle le plus pertinent : Conseil, Digital ou Data — et parfois une combinaison des trois."),
        array('general', 'Travaillez-vous avec les TPE/PME comme avec les grands comptes ?',
              "Oui. Nous adaptons la profondeur de l'accompagnement à la taille et à la maturité. La méthode reste la même : cadrage clair, livrables mesurables, décision par la preuve."),
        array('conseil', 'À quoi ressemble une mission de conseil chez La Lignée ?',
              "Une phase de cadrage (2 à 3 semaines) pour poser le diagnostic, puis un plan d'action opérationnel avec jalons courts. Nous restons impliqués jusqu'au premier résultat mesurable."),
        array('conseil', 'Pouvez-vous accompagner un lancement de marque ou une refonte de positionnement ?',
              "Oui : audit, plateforme de marque, territoire d'expression, roadmap de mise en marché. Nous travaillons main dans la main avec vos équipes créatives ou les nôtres."),
        array('digital', 'Concevez-vous des sites, applications ou outils sur-mesure ?',
              "Oui. Sites vitrines, e-commerce, plateformes métiers, automatisations internes. Nous choisissons la stack la plus sobre pour votre besoin, jamais l'inverse."),
        array('digital', 'Assurez-vous la maintenance après la livraison ?',
              "Oui, via des contrats de suivi mensuels : monitoring, correctifs, évolutions, sécurité. Vous gardez la propriété du code et des accès."),
        array('data', 'Que faites-vous concrètement en Data ?',
              "Nous rendons vos données lisibles et actionnables : collecte fiable, tableaux de bord clairs, indicateurs qui déclenchent des décisions. Pas de dashboard pour le décor."),
        array('data', 'Faut-il déjà avoir un CRM ou un ERP pour travailler avec vous ?',
              "Non. Nous partons de ce que vous avez — même un tableur — et faisons grandir l'écosystème seulement quand c'est justifié."),
        array('general', 'Comment démarrer une collaboration ?',
              "Un email ou le formulaire de contact suffit. Un premier échange (30 min) permet de qualifier le besoin. Nous revenons ensuite avec une proposition d'intervention adaptée."),
    );

    foreach ($seed as $i => $row) {
        list($theme_slug, $q, $a) = $row;
        $id = wp_insert_post(array(
            'post_type'    => 'la_faq',
            'post_status'  => 'publish',
            'post_title'   => $q,
            'post_content' => $a,
            'menu_order'   => $i,
        ));
        if ($id && !is_wp_error($id) && !empty($term_ids[$theme_slug])) {
            wp_set_object_terms($id, array($term_ids[$theme_slug]), 'faq_theme');
        }
    }

    update_option('la_lignee_faq_seeded', 1);
}
add_action('after_switch_theme', 'la_lignee_seed_faq');
