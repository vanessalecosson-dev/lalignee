<?php
/**
 * Front page — La Lignée
 */
if (!defined('ABSPATH')) exit;
get_header();
?>

<header class="hero">
  <div class="wrap">
    <p class="eyebrow"><?php echo esc_html(la_lignee_opt('hero_eyebrow','Conseil & stratégie · Abidjan')); ?></p>
    <h1 class="hero-mark">La&nbsp;Ligné<span class="accent">e</span></h1>
    <div class="hero-rule"></div>
    <p class="hero-tag"><?php echo esc_html(la_lignee_opt('hero_tag','Penser juste, déployer vite, décider par la preuve. Nous accompagnons les marques qui veulent grandir avec méthode.')); ?></p>
    <p class="hero-sub"><?php echo esc_html(la_lignee_opt('hero_sub','Stratégie · Digital & Tech · Data')); ?></p>
    <div class="hero-ctas">
      <a href="#contact" class="btn btn-gold">Prendre contact</a>
      <a href="#methode" class="btn btn-ghost">Notre méthode</a>
    </div>
  </div>
</header>

<div class="thread-wrap band">
  <div class="thread-line"></div>
  <div class="node reveal">
    <p class="lead">Trop de marques exécutent avant d'avoir pensé, et décident à l'instinct.<br>Nous remettons la <em>stratégie</em> et la <em>donnée</em> au centre.</p>
  </div>
</div>

<section id="cabinet">
  <div class="wrap-narrow">
    <div class="section-head reveal">
      <p class="eyebrow">Qui nous sommes</p>
      <h2>Un cabinet, pas un prestataire</h2>
    </div>
    <p class="lead reveal">La Lignée est née d'une expérience d'entrepreneur : celle d'avoir positionné, déployé et fait grandir de vraies marques. Nous ne vendons pas du « joli ». Nous vendons des décisions justes — et la capacité, rare, de les <em>mener jusqu'au résultat</em>.</p>
  </div>
</section>

<section class="band" id="methode">
  <div class="wrap">
    <div class="section-head reveal">
      <p class="eyebrow">Notre méthode</p>
      <h2>Penser, déployer, mesurer</h2>
    </div>
    <p class="tri-intro reveal">Nos trois pôles ne s'empilent pas : ils s'enchaînent. Chaque mesure nourrit la stratégie suivante. C'est un cycle continu — votre marque inscrite dans une lignée.</p>
    <div class="triptych reveal">
      <div class="tri-step"><div class="tri-dot"></div><div class="verb">Penser</div><div class="field">Conseil &amp; Stratégie</div><p>Diagnostic, positionnement, plateforme de marque et stratégie de croissance. La direction avant le mouvement.</p></div>
      <div class="tri-step"><div class="tri-dot"></div><div class="verb">Déployer</div><div class="field">Digital &amp; Tech</div><p>Présence digitale, contenus, sites et solutions techniques sur mesure. La stratégie qui prend forme.</p></div>
      <div class="tri-step"><div class="tri-dot"></div><div class="verb">Mesurer</div><div class="field">Data &amp; Analyse</div><p>Tableaux de bord, lecture de la performance et des données clients. La preuve qui éclaire la décision.</p></div>
    </div>
  </div>
</section>

<section id="poles">
  <div class="wrap-narrow">
    <div class="section-head reveal"><p class="eyebrow">Pôle I</p><h2>Conseil &amp; Stratégie</h2><div class="pole-tag"><span class="verb">Penser</span></div></div>
    <div class="offer-group reveal">
      <div class="offer"><div class="name">Diagnostic stratégique</div><div class="desc">Audit 360° — marque, positionnement, communication, présence digitale — et plan d'action priorisé. La porte d'entrée.</div></div>
      <div class="offer"><div class="name">Plateforme de marque</div><div class="desc">Positionnement, territoire, ton de voix et architecture de marque. Le socle dont découle tout le reste.</div></div>
      <div class="offer"><div class="name">Stratégie de croissance</div><div class="desc">Go-to-market, plan de communication, structuration de l'offre commerciale et des canaux d'acquisition.</div></div>
      <div class="offer"><div class="name">Accompagnement de dirigeant</div><div class="desc">Un partenaire stratégique à vos côtés, au mois. Conseil continu, regard extérieur, aide à la décision.</div></div>
    </div>
  </div>
</section>

<section class="band">
  <div class="wrap-narrow">
    <div class="section-head reveal"><p class="eyebrow">Pôle II</p><h2>Digital &amp; Tech</h2><div class="pole-tag"><span class="verb">Déployer</span></div></div>
    <div class="offer-group reveal">
      <div class="offer"><div class="name">Sites &amp; écosystèmes digitaux</div><div class="desc">Site vitrine ou éditorial à l'image d'une maison premium, pensé pour servir le positionnement.</div></div>
      <div class="offer"><div class="name">Solutions tech sur mesure</div><div class="desc">CRM, outils internes, automatisations, applicatifs métier. Notre signature : un cabinet qui sait aussi construire.</div></div>
      <div class="offer"><div class="name">Présence &amp; contenu digital</div><div class="desc">Community management, création de contenu et pilotage éditorial — en extension d'un accompagnement.</div></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap-narrow">
    <div class="section-head reveal"><p class="eyebrow">Pôle III</p><h2>Data &amp; Analyse</h2><div class="pole-tag"><span class="verb">Mesurer</span></div></div>
    <div class="offer-group reveal">
      <div class="offer"><div class="name">Tableau de bord de pilotage</div><div class="desc">Vos indicateurs clés réunis et lisibles — ventes, audience, performance — pour décider d'un coup d'œil.</div></div>
      <div class="offer"><div class="name">Analyse de performance</div><div class="desc">Lecture de vos campagnes, de votre présence et de vos canaux. Ce qui marche, ce qui coûte, ce qu'il faut corriger.</div></div>
      <div class="offer"><div class="name">Insights clients &amp; marché</div><div class="desc">Exploitation de vos données clients et veille concurrentielle pour nourrir la stratégie par la preuve.</div></div>
    </div>
  </div>
</section>

<section class="band" id="principes">
  <div class="wrap-narrow">
    <div class="section-head reveal"><p class="eyebrow">Notre manière de travailler</p><h2>Une relation, pas une prestation</h2></div>
    <div class="principles reveal">
      <div class="principle"><div class="num">I</div><h4>La pensée avant l'action</h4><p>On ne déploie rien sans savoir pourquoi. La stratégie commande, l'exécution suit.</p></div>
      <div class="principle"><div class="num">II</div><h4>La preuve par la donnée</h4><p>On mesure, on lit, on ajuste. Les décisions s'appuient sur des faits, pas des impressions.</p></div>
      <div class="principle"><div class="num">III</div><h4>La durée comme cadre</h4><p>Accompagnement au long cours, périmètres clairs, engagement mutuel.</p></div>
    </div>
  </div>
</section>


<?php
// Réalisations à la une
$rea = new WP_Query(array('post_type' => 'realisation', 'posts_per_page' => 3));
if ($rea->have_posts()) : ?>
<section id="realisations">
  <div class="wrap">
    <div class="section-head reveal"><p class="eyebrow">Réalisations</p><h2>Quelques études de cas</h2></div>
    <div class="realisations-grid reveal">
      <?php while ($rea->have_posts()) : $rea->the_post();
        $client = get_post_meta(get_the_ID(), '_ll_client', true);
        $annee  = get_post_meta(get_the_ID(), '_ll_annee', true);
        $terms  = wp_get_post_terms(get_the_ID(), 'pole');
      ?>
        <a class="rea-card" href="<?php the_permalink(); ?>">
          <div class="rea-thumb">
            <?php if (has_post_thumbnail()) the_post_thumbnail('la-lignee-card');
            else echo '<div class="rea-placeholder">La Lignée</div>'; ?>
          </div>
          <div class="rea-body">
            <div class="rea-meta"><?php if (!empty($terms) && !is_wp_error($terms)) echo esc_html($terms[0]->name); if ($annee) echo ' · ' . esc_html($annee); ?></div>
            <h3 class="rea-title"><?php the_title(); ?></h3>
            <?php if ($client) : ?><div class="rea-client"><?php echo esc_html($client); ?></div><?php endif; ?>
            <span class="rea-arrow">Voir l'étude →</span>
          </div>
        </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <div style="text-align:center;margin-top:50px">
      <a href="<?php echo esc_url(get_post_type_archive_link('realisation')); ?>" class="btn btn-gold" style="background:var(--gold);color:var(--ink)">Toutes les réalisations</a>
    </div>
  </div>
</section>
<?php endif; ?>


<?php
// Latest journal entries (optional)
$latest = new WP_Query(array('posts_per_page' => 3, 'ignore_sticky_posts' => true));
if ($latest->have_posts()) : ?>
<section id="journal">
  <div class="wrap">
    <div class="section-head reveal"><p class="eyebrow">Journal</p><h2>Nos dernières lectures</h2></div>
    <div class="posts-grid reveal">
      <?php while ($latest->have_posts()) : $latest->the_post(); ?>
        <?php get_template_part('template-parts/card', 'post'); ?>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php get_template_part('template-parts/faq-section'); ?>

<?php get_template_part('template-parts/contact-section'); ?>

<?php get_footer(); ?>
