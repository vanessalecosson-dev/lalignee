<?php if (!defined('ABSPATH')) exit; ?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
  <label class="screen-reader-text" for="s">Rechercher :</label>
  <input type="search" id="s" class="search-field" placeholder="Rechercher…" value="<?php echo esc_attr(get_search_query()); ?>" name="s" style="width:100%;padding:12px 14px;border:1px solid var(--line);background:var(--cream);font-family:'Jost',sans-serif">
  <button type="submit" class="btn btn-gold" style="margin-top:12px;background:var(--gold);color:var(--ink)">Rechercher</button>
</form>
