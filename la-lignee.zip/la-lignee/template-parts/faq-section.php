<?php
/**
 * Template part: FAQ filtrable par thème
 * Utilise le CPT `la_faq` + taxonomie `faq_theme`.
 */
if (!defined('ABSPATH')) exit;

$faq_query = new WP_Query(array(
    'post_type'      => 'la_faq',
    'posts_per_page' => -1,
    'orderby'        => array('menu_order' => 'ASC', 'date' => 'ASC'),
));

if (!$faq_query->have_posts()) return;

$themes = get_terms(array(
    'taxonomy'   => 'faq_theme',
    'hide_empty' => true,
));
?>
<section class="faq" id="faq" aria-labelledby="faq-title">
  <div class="wrap-narrow">
    <p class="eyebrow">Questions fréquentes</p>
    <h2 id="faq-title">Aider votre choix, sans tourner autour</h2>
    <p class="faq-tag">Filtrez par thème pour identifier le pôle qui correspond à votre besoin.</p>
    <div class="ct-rule"></div>

    <?php if (!empty($themes) && !is_wp_error($themes)) : ?>
      <div class="faq-filter" role="tablist" aria-label="Filtrer les questions par thème">
        <button type="button" class="faq-chip is-active" data-faq-filter="all">Tout voir <span class="faq-count">(<?php echo (int) $faq_query->found_posts; ?>)</span></button>
        <?php foreach ($themes as $t) : ?>
          <button type="button" class="faq-chip" data-faq-filter="<?php echo esc_attr($t->slug); ?>">
            <?php echo esc_html($t->name); ?> <span class="faq-count">(<?php echo (int) $t->count; ?>)</span>
          </button>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <ul class="faq-list" id="faq-list">
      <?php while ($faq_query->have_posts()) : $faq_query->the_post();
        $terms = get_the_terms(get_the_ID(), 'faq_theme');
        $slugs = array();
        if ($terms && !is_wp_error($terms)) {
          foreach ($terms as $tt) $slugs[] = $tt->slug;
        }
      ?>
        <li class="faq-item" data-themes="<?php echo esc_attr(implode(' ', $slugs)); ?>">
          <details>
            <summary>
              <span class="faq-q"><?php the_title(); ?></span>
              <span class="faq-toggle" aria-hidden="true"></span>
            </summary>
            <div class="faq-a"><?php the_content(); ?></div>
            <?php if (!empty($slugs)) : ?>
              <p class="faq-tags"><?php foreach ($terms as $tt) : ?><span class="faq-tag-pill"><?php echo esc_html($tt->name); ?></span><?php endforeach; ?></p>
            <?php endif; ?>
          </details>
        </li>
      <?php endwhile; wp_reset_postdata(); ?>
    </ul>

    <p class="faq-empty" hidden>Aucune question dans ce thème pour le moment.</p>

    <p class="faq-cta">
      Une question qui n'est pas ici ?
      <a href="#contact" class="link-arrow">Écrivez-nous directement →</a>
    </p>
  </div>
</section>

<?php
// JSON-LD FAQPage (SEO)
$faq_query->rewind_posts();
$ld = array('@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array());
while ($faq_query->have_posts()) { $faq_query->the_post();
    $ld['mainEntity'][] = array(
        '@type' => 'Question',
        'name'  => wp_strip_all_tags(get_the_title()),
        'acceptedAnswer' => array(
            '@type' => 'Answer',
            'text'  => wp_strip_all_tags(apply_filters('the_content', get_the_content())),
        ),
    );
}
wp_reset_postdata();
echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
