<?php if (!defined('ABSPATH')) exit; ?>
<article class="post-card">
  <a class="thumb" href="<?php the_permalink(); ?>">
    <?php if (has_post_thumbnail()) : the_post_thumbnail('la-lignee-card', array('alt' => the_title_attribute(array('echo' => false)))); ?>
    <?php else : ?>
      <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:var(--cream-deep);color:var(--gold);font-family:'Cormorant Garamond',serif;font-size:2.4rem;font-style:italic">La Lignée</div>
    <?php endif; ?>
  </a>
  <div class="body">
    <?php $cats = get_the_category(); if (!empty($cats)) : ?>
      <div class="cat"><?php echo esc_html($cats[0]->name); ?></div>
    <?php endif; ?>
    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <p class="excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
    <div class="meta"><?php echo esc_html(get_the_date()); ?></div>
  </div>
</article>
