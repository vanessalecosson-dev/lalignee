<?php if (!defined('ABSPATH')) exit;
$lg_opts = function_exists('la_lignee_contact_get_options') ? la_lignee_contact_get_options() : array('antispam_math' => 1);
$lg_cap  = !empty($lg_opts['antispam_math']) && function_exists('la_lignee_captcha_challenge') ? la_lignee_captcha_challenge() : null;
?>
<section class="contact" id="contact">
  <div class="wrap-narrow">
    <p class="eyebrow">Entrons en lignée</p>
    <h2>Parlons de votre marque</h2>
    <p class="ct-tag">Un échange suffit pour savoir si nous sommes faits pour travailler ensemble.</p>
    <div class="ct-rule"></div>

    <div class="ct-details">
      <?php $email = la_lignee_opt('email','contact@lalignee.ci'); ?>
      <?php $phone = la_lignee_opt('phone','+225 00 00 00 00'); ?>
      <?php $addr  = la_lignee_opt('address','Abidjan, Côte d\'Ivoire'); ?>
      <span><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></span>
      <span><a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$phone)); ?>"><?php echo esc_html($phone); ?></a></span>
      <span><?php echo esc_html($addr); ?></span>
    </div>

    <form id="la-lignee-contact-form" class="contact-form" novalidate>
      <?php wp_nonce_field('la_lignee_contact', '_wpnonce', false, true); ?>
      <input type="hidden" name="form_started" value="<?php echo esc_attr(time()); ?>">

      <div class="row">
        <div>
          <label for="lg-nom">Nom</label>
          <input type="text" id="lg-nom" name="nom" required maxlength="120">
        </div>
        <div>
          <label for="lg-email">Email</label>
          <input type="email" id="lg-email" name="email" required maxlength="180">
        </div>
      </div>
      <div class="row">
        <div>
          <label for="lg-entreprise">Entreprise</label>
          <input type="text" id="lg-entreprise" name="entreprise" maxlength="150">
        </div>
        <div>
          <label for="lg-pole">Pôle concerné</label>
          <select id="lg-pole" name="pole">
            <option value="">— Au choix —</option>
            <option>Conseil &amp; Stratégie</option>
            <option>Digital &amp; Tech</option>
            <option>Data &amp; Analyse</option>
            <option>Autre</option>
          </select>
        </div>
      </div>
      <label for="lg-message">Votre projet</label>
      <textarea id="lg-message" name="message" required minlength="10" maxlength="5000"></textarea>

      <?php if ($lg_cap): ?>
      <div class="row row-captcha">
        <div>
          <label for="lg-cap"><?php echo esc_html($lg_cap['question']); ?> <span aria-hidden="true">*</span></label>
          <input type="text" id="lg-cap" name="cap_answer" inputmode="numeric" pattern="[0-9]*" autocomplete="off" required>
          <input type="hidden" name="cap_token" value="<?php echo esc_attr($lg_cap['token']); ?>">
        </div>
      </div>
      <?php endif; ?>

      <!-- Honeypot anti-spam (ne pas remplir) -->
      <div aria-hidden="true" style="position:absolute;left:-9999px;height:0;width:0;overflow:hidden">
        <label for="lg-website">Site web</label>
        <input type="text" id="lg-website" name="website" tabindex="-1" autocomplete="off">
      </div>

      <div style="text-align:center">
        <button type="submit" class="btn btn-gold">Envoyer</button>
      </div>
      <div class="form-msg" role="status" aria-live="polite"></div>
    </form>
  </div>
</section>
