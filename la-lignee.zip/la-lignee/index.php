<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<header class="page-header">
  <p class="eyebrow">Journal</p>
  <h1><?php echo is_home() ? 'Journal' : wp_get_document_title(); ?></h1>
  <p class="lead">Notes, lectures et prises de position — la pensée du cabinet.</p>
</header>

<section>
  <div class="wrap">
    <?php if (have_posts()) : ?>
      <div class="posts-grid">
        <?php while (have_posts()) : the_post(); ?>
          <?php get_template_part('template-parts/card', 'post'); ?>
        <?php endwhile; ?>
      </div>
      <?php la_lignee_pagination(); ?>
    <?php else : ?>
      <p class="lead">Aucun article pour l'instant.</p>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
