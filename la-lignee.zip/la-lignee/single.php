<?php
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
<article class="single-post-content">
  <div class="meta-top">
    <?php $cats = get_the_category(); if (!empty($cats)) echo esc_html($cats[0]->name) . ' · '; ?>
    <?php echo esc_html(get_the_date()); ?>
  </div>
  <h1><?php the_title(); ?></h1>

  <?php if (has_post_thumbnail()) : ?>
    <div class="featured"><?php the_post_thumbnail('la-lignee-hero'); ?></div>
  <?php endif; ?>

  <div class="content">
    <?php the_content(); ?>
    <?php wp_link_pages(); ?>
  </div>
</article>

<?php if (comments_open() || get_comments_number()) : ?>
  <div class="wrap-narrow" style="padding-bottom:80px"><?php comments_template(); ?></div>
<?php endif; ?>

<?php endwhile; ?>

<?php get_template_part('template-parts/contact-section'); ?>
<?php get_footer(); ?>
