<?php
/**
 * Single : Réalisation
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post();
  $client  = get_post_meta(get_the_ID(), '_ll_client', true);
  $annee   = get_post_meta(get_the_ID(), '_ll_annee', true);
  $mission = get_post_meta(get_the_ID(), '_ll_mission', true);
  $lien    = get_post_meta(get_the_ID(), '_ll_lien', true);
  $poles   = wp_get_post_terms(get_the_ID(), 'pole');
  $secteurs= wp_get_post_terms(get_the_ID(), 'secteur');
?>

<header class="page-header rea-header">
  <p class="eyebrow">
    <?php if (!empty($poles) && !is_wp_error($poles)) echo esc_html($poles[0]->name);
    if ($annee) echo ' · ' . esc_html($annee); ?>
  </p>
  <h1><?php the_title(); ?></h1>
  <?php if ($client) : ?><p class="lead" style="font-style:italic">Pour <?php echo esc_html($client); ?></p><?php endif; ?>
</header>

<?php if (has_post_thumbnail()) : ?>
  <div class="rea-hero-image"><?php the_post_thumbnail('la-lignee-hero'); ?></div>
<?php endif; ?>

<article class="single-post-content rea-single">
  <?php if ($mission || !empty($secteurs) || $lien) : ?>
  <aside class="rea-facts">
    <?php if ($mission) : ?>
      <div><div class="fact-label">Mission</div><div class="fact-value"><?php echo esc_html($mission); ?></div></div>
    <?php endif; ?>
    <?php if ($client) : ?>
      <div><div class="fact-label">Client</div><div class="fact-value"><?php echo esc_html($client); ?></div></div>
    <?php endif; ?>
    <?php if (!empty($secteurs) && !is_wp_error($secteurs)) : ?>
      <div><div class="fact-label">Secteur</div><div class="fact-value">
        <?php echo esc_html(implode(', ', wp_list_pluck($secteurs, 'name'))); ?>
      </div></div>
    <?php endif; ?>
    <?php if ($annee) : ?>
      <div><div class="fact-label">Année</div><div class="fact-value"><?php echo esc_html($annee); ?></div></div>
    <?php endif; ?>
    <?php if ($lien) : ?>
      <div><div class="fact-label">En ligne</div><div class="fact-value"><a href="<?php echo esc_url($lien); ?>" target="_blank" rel="noopener">Voir le projet ↗</a></div></div>
    <?php endif; ?>
  </aside>
  <?php endif; ?>

  <div class="content"><?php the_content(); ?></div>
</article>

<?php
// Réalisations connexes (même pôle)
if (!empty($poles) && !is_wp_error($poles)) {
    $related = new WP_Query(array(
        'post_type' => 'realisation',
        'posts_per_page' => 3,
        'post__not_in' => array(get_the_ID()),
        'tax_query' => array(array('taxonomy' => 'pole', 'field' => 'term_id', 'terms' => $poles[0]->term_id)),
    ));
    if ($related->have_posts()) : ?>
      <section class="band">
        <div class="wrap">
          <div class="section-head reveal"><p class="eyebrow">À découvrir aussi</p><h2>Autres réalisations</h2></div>
          <div class="realisations-grid">
            <?php while ($related->have_posts()) : $related->the_post();
              $rclient = get_post_meta(get_the_ID(), '_ll_client', true);
              $rannee  = get_post_meta(get_the_ID(), '_ll_annee', true);
              $rterms  = wp_get_post_terms(get_the_ID(), 'pole');
            ?>
              <a class="rea-card" href="<?php the_permalink(); ?>">
                <div class="rea-thumb">
                  <?php if (has_post_thumbnail()) the_post_thumbnail('la-lignee-card');
                  else echo '<div class="rea-placeholder">La Lignée</div>'; ?>
                </div>
                <div class="rea-body">
                  <div class="rea-meta">
                    <?php if (!empty($rterms) && !is_wp_error($rterms)) echo esc_html($rterms[0]->name);
                    if ($rannee) echo ' · ' . esc_html($rannee); ?>
                  </div>
                  <h3 class="rea-title"><?php the_title(); ?></h3>
                  <?php if ($rclient) : ?><div class="rea-client"><?php echo esc_html($rclient); ?></div><?php endif; ?>
                </div>
              </a>
            <?php endwhile; ?>
          </div>
        </div>
      </section>
    <?php endif; wp_reset_postdata();
}
?>

<?php endwhile; ?>

<?php get_template_part('template-parts/contact-section'); ?>
<?php get_footer(); ?>
