<?php
if (!defined('ABSPATH')) exit;
if (post_password_required()) return; ?>

<div id="comments" class="comments-area" style="margin-top:60px">
  <?php if (have_comments()) : ?>
    <h3 class="serif" style="font-size:1.6rem;margin-bottom:20px"><?php comments_number('Aucun commentaire', 'Un commentaire', '% commentaires'); ?></h3>
    <ol class="comment-list" style="list-style:none;padding:0">
      <?php wp_list_comments(array('style' => 'ol', 'short_ping' => true, 'avatar_size' => 48)); ?>
    </ol>
    <?php the_comments_navigation(); ?>
  <?php endif; ?>

  <?php if (!comments_open() && get_comments_number() && post_type_supports(get_post_type(), 'comments')) : ?>
    <p><?php esc_html_e('Les commentaires sont fermés.', 'la-lignee'); ?></p>
  <?php endif; ?>

  <?php comment_form(array(
    'title_reply' => 'Laisser un commentaire',
    'class_submit' => 'btn btn-gold',
  )); ?>
</div>
