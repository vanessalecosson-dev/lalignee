export type Realisation = {
  slug: string;
  pole: "Penser" | "Déployer" | "Mesurer";
  client: string;
  title: string;
  kpi: string;
  year: string;
  duration: string;
  summary: string;
  challenge: string;
  approach: string[];
  results: { k: string; v: string }[];
};

export const realisations: Realisation[] = [
  {
    slug: "refonte-parcours-b2b",
    pole: "Déployer",
    client: "Groupe industriel",
    title: "Refonte du parcours client B2B",
    kpi: "+38% de conversion",
    year: "2025",
    duration: "6 mois",
    summary: "Refonte de bout en bout du parcours commercial digital d'un équipementier européen.",
    challenge: "Un site institutionnel qui ne convertissait pas et un tunnel de demande de devis morcelé entre trois outils différents.",
    approach: [
      "Diagnostic UX et cartographie du parcours existant",
      "Ateliers de co-conception avec les équipes ventes et marketing",
      "Nouveau design system et refonte du tunnel de demande",
      "Mise en place d'un suivi analytique unifié",
    ],
    results: [
      { k: "+38%", v: "conversion tunnel" },
      { k: "−52%", v: "temps de qualification" },
      { k: "×2,4", v: "leads qualifiés / mois" },
    ],
  },
  {
    slug: "plateforme-data-unifiee",
    pole: "Mesurer",
    client: "ETI Assurance",
    title: "Plateforme data unifiée",
    kpi: "−45% délai de reporting",
    year: "2024",
    duration: "9 mois",
    summary: "Construction d'un socle data unifié et d'un dispositif de pilotage exécutif.",
    challenge: "Un reporting mensuel produit à la main par 4 équipes, avec des chiffres qui divergeaient d'un COMEX à l'autre.",
    approach: [
      "Cartographie des sources et arbitrage sur les définitions",
      "Mise en place d'un entrepôt de données consolidé",
      "Dashboards dirigeants et opérationnels",
      "Formation des relais métiers",
    ],
    results: [
      { k: "−45%", v: "délai de reporting" },
      { k: "1", v: "source de vérité" },
      { k: "12", v: "dashboards actifs" },
    ],
  },
  {
    slug: "modele-omnicanal",
    pole: "Penser",
    client: "Retailer premium",
    title: "Nouveau modèle omnicanal",
    kpi: "Time-to-market : 18 mois",
    year: "2024",
    duration: "4 mois",
    summary: "Définition de la trajectoire omnicanale d'une maison française pour ses 200 boutiques.",
    challenge: "Aligner boutiques, digital et service client sur une expérience de marque unique, sans perdre la singularité du point de vente.",
    approach: [
      "Immersion en boutique et écoute clients",
      "Benchmark international et modélisation économique",
      "Trajectoire à 18 mois validée en CODIR",
    ],
    results: [
      { k: "18 mois", v: "time-to-market" },
      { k: "3", v: "chantiers prioritaires" },
      { k: "100%", v: "adhésion CODIR" },
    ],
  },
  {
    slug: "design-system-marques",
    pole: "Déployer",
    client: "Groupe familial",
    title: "Design system multi-marques",
    kpi: "5 marques harmonisées",
    year: "2025",
    duration: "5 mois",
    summary: "Un design system unique pour cinq marques, avec variations chromatiques et typographiques.",
    challenge: "Cinq sites héritent de cinq histoires visuelles ; les équipes internes ne parviennent plus à maintenir la cohérence.",
    approach: [
      "Audit des composants existants",
      "Conception d'un système de tokens multi-marques",
      "Documentation vivante et bibliothèque Figma",
    ],
    results: [
      { k: "5", v: "marques alignées" },
      { k: "80+", v: "composants versionnés" },
      { k: "−60%", v: "temps de mise en production" },
    ],
  },
  {
    slug: "plateforme-de-marque",
    pole: "Penser",
    client: "Cabinet d'avocats",
    title: "Plateforme de marque & positionnement",
    kpi: "Repositionnement 2026",
    year: "2025",
    duration: "3 mois",
    summary: "Nouvelle plateforme de marque pour un cabinet d'avocats de niche.",
    challenge: "Un cabinet reconnu par ses pairs mais peu visible auprès de ses clients cibles.",
    approach: [
      "Entretiens associés, clients, prospects",
      "Atelier de vision et arbitrages de positionnement",
      "Plateforme de marque et récit fondateur",
    ],
    results: [
      { k: "1", v: "récit unifié" },
      { k: "4", v: "axes de communication" },
      { k: "12", v: "prises de parole planifiées" },
    ],
  },
  {
    slug: "dashboard-comex",
    pole: "Mesurer",
    client: "Foncière européenne",
    title: "Dashboard COMEX temps réel",
    kpi: "Décisions accélérées",
    year: "2024",
    duration: "4 mois",
    summary: "Un tableau de bord unique pour les décisions du comité exécutif hebdomadaire.",
    challenge: "Le COMEX prenait ses décisions avec des chiffres à 3 semaines de décalage.",
    approach: [
      "Sélection de 8 KPIs stratégiques",
      "Intégration des sources opérationnelles",
      "Design d'un dashboard sobre et lisible",
    ],
    results: [
      { k: "J+1", v: "fraîcheur des données" },
      { k: "8", v: "KPIs suivis" },
      { k: "40 min", v: "gagnées / COMEX" },
    ],
  },
];

export function getRealisation(slug: string) {
  return realisations.find((r) => r.slug === slug);
}
