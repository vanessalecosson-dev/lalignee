import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";

export const Route = createFileRoute("/confidentialite")({
  head: () => ({
    meta: [
      { title: "Confidentialité — La Lignée" },
      { name: "description", content: "Politique de confidentialité et traitement des données personnelles du site La Lignée." },
      { property: "og:title", content: "Confidentialité — La Lignée" },
      { property: "og:description", content: "Politique de confidentialité du site La Lignée." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <PageHero eyebrow="— Vos données" title={<>Politique de <span className="italic text-gold-soft">confidentialité.</span></>} intro="Nous collectons le strict nécessaire et ne partageons rien. Voici comment vos données sont traitées." />

      <section className="py-20">
        <div className="mx-auto max-w-3xl px-6 lg:px-10 space-y-10 text-foreground/85 leading-relaxed">
          <div>
            <h2 className="serif text-2xl mb-3">Données collectées</h2>
            <p>Via le formulaire de contact : nom, email, organisation et contenu du message. Aucune donnée sensible n'est demandée.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Finalité</h2>
            <p>Ces données servent uniquement à répondre à votre demande. Elles ne sont ni revendues, ni transmises à des tiers.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Conservation</h2>
            <p>Les messages sont conservés 24 mois maximum, sauf ouverture d'une mission active.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Vos droits</h2>
            <p>Vous disposez d'un droit d'accès, de rectification et de suppression. Pour l'exercer : <a href="mailto:contact@la-lignee.fr" className="link-underline">contact@la-lignee.fr</a>.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Cookies</h2>
            <p>Le site utilise uniquement des cookies techniques nécessaires à son fonctionnement. Aucun cookie publicitaire ni de suivi tiers.</p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
