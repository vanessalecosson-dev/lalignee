import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";

export const Route = createFileRoute("/mentions-legales")({
  head: () => ({
    meta: [
      { title: "Mentions légales — La Lignée" },
      { name: "description", content: "Mentions légales du site du cabinet La Lignée." },
      { property: "og:title", content: "Mentions légales — La Lignée" },
      { property: "og:description", content: "Mentions légales du site La Lignée." },
    ],
  }),
  component: LegalPage,
});

function LegalPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <PageHero eyebrow="— Informations" title={<>Mentions <span className="italic text-gold-soft">légales.</span></>} />

      <section className="py-20">
        <div className="mx-auto max-w-3xl px-6 lg:px-10 space-y-10 text-foreground/85 leading-relaxed">
          <div>
            <h2 className="serif text-2xl mb-3">Éditeur</h2>
            <p>La Lignée SAS — Cabinet de conseil<br />12 rue de la Paix, 75002 Paris<br />RCS Paris 000 000 000 · SIRET 000 000 000 00000<br />Capital social : 10 000 €</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Direction de la publication</h2>
            <p>Camille Roussel, présidente de La Lignée SAS.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Hébergement</h2>
            <p>Le site est hébergé par un prestataire européen conforme au RGPD.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Propriété intellectuelle</h2>
            <p>L'ensemble des contenus (textes, images, marques) est protégé. Toute reproduction sans autorisation écrite est interdite.</p>
          </div>
          <div>
            <h2 className="serif text-2xl mb-3">Contact</h2>
            <p><a href="mailto:contact@la-lignee.fr" className="link-underline">contact@la-lignee.fr</a></p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
