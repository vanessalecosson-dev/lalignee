import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import hero from "@/assets/hero-lignee.jpg";
import team1 from "@/assets/team-1.jpg";
import lineTexture from "@/assets/texture-line.jpg";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/")({
  component: Landing,
});

const services = [
  {
    n: "01",
    step: "Penser",
    title: "Conseil & Stratégie",
    desc: "Diagnostic, positionnement, plateforme de marque. La direction avant le mouvement.",
    tags: ["Diagnostic", "Positionnement", "Marque"],
  },
  {
    n: "02",
    step: "Déployer",
    title: "Digital & Tech",
    desc: "Sites, contenus et solutions techniques sur mesure. La stratégie qui prend forme.",
    tags: ["Web", "Contenus", "Sur-mesure"],
  },
  {
    n: "03",
    step: "Mesurer",
    title: "Data & Analyse",
    desc: "Tableaux de bord et lecture de la performance. La preuve qui éclaire la décision.",
    tags: ["Dashboards", "KPIs", "Analyse"],
  },
];

const cases = [
  { pole: "Digital", client: "Groupe industriel", title: "Refonte du parcours client B2B", kpi: "+38% de conversion" },
  { pole: "Data", client: "ETI Assurance", title: "Plateforme data unifiée", kpi: "−45% délai de reporting" },
  { pole: "Stratégie", client: "Retailer premium", title: "Nouveau modèle omnicanal", kpi: "18 mois → time-to-market" },
];

const faqs = [
  { q: "Comment démarre une mission avec La Lignée ?", a: "Par une conversation. Un premier échange de 45 minutes permet de comprendre l'enjeu, puis nous formalisons une note de cadrage avant tout engagement." },
  { q: "Intervenez-vous en France uniquement ?", a: "Notre équipe est basée à Paris et Lyon, et nous intervenons partout en France ainsi qu'en Europe francophone." },
  { q: "Comment protégez-vous la confidentialité ?", a: "Chaque mission est encadrée par un NDA. Les livrables et données restent votre propriété exclusive." },
];

function Landing() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader transparent />


      {/* HERO */}
      <section id="top" className="relative min-h-screen overflow-hidden">
        <div className="absolute inset-0">
          <img src={hero} alt="" className="h-full w-full object-cover ken-burns" />
          <div className="absolute inset-0 bg-gradient-to-b from-navy-deep/70 via-navy/50 to-background" />
        </div>

        <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col justify-end px-6 pb-24 pt-40 lg:px-10">
          <div className="flex items-center gap-4 mb-8 reveal">
            <span className="h-px w-14 bg-gold" />
            <span className="text-[11px] uppercase tracking-widest-2 text-gold-soft">Cabinet de conseil · depuis 2018</span>
          </div>

          <h1 className="serif text-[clamp(2.75rem,8vw,7.5rem)] leading-[0.95] text-ivory reveal delay-1">
            Tracer la ligne <br />
            <span className="italic font-light text-gold-soft">de vos </span>
            <span className="shimmer-text italic font-light">transformations.</span>
          </h1>

          <p className="mt-8 max-w-xl text-lg text-ivory/80 reveal delay-2">
            La Lignée accompagne les dirigeants et leurs équipes dans les décisions
            qui comptent — avec rigueur, discrétion et un attachement profond
            au geste bien fait.
          </p>

          <div className="mt-12 flex flex-wrap items-center gap-5 reveal delay-3">
            <Link
              to="/contact"
              className="btn-gold inline-flex items-center gap-3 rounded-full bg-gold px-8 py-4 text-[12px] uppercase tracking-widest-2 text-navy-deep font-medium hover:bg-gold-soft transition-colors duration-500"
            >
              <span className="relative z-10">Prendre rendez-vous</span>
              <span className="relative z-10">→</span>
            </Link>
            <Link to="/methode" className="text-ivory/80 text-[12px] uppercase tracking-widest-2 link-underline">
              Découvrir notre méthode
            </Link>
          </div>


          <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-ivory/15 pt-10 reveal delay-4">
            {[
              ["120+", "missions conduites"],
              ["30", "clients fidèles"],
              ["3", "pôles d'expertise"],
              ["7 ans", "de savoir-faire"],
            ].map(([k, v]) => (
              <div key={v}>
                <div className="serif text-4xl text-ivory">{k}</div>
                <div className="mt-2 text-xs uppercase tracking-widest-2 text-ivory/60">{v}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="absolute right-6 bottom-8 hidden lg:flex items-center gap-3 text-ivory/60">
          <span className="vertical-text text-[10px] uppercase">scroll</span>
          <span className="block h-16 w-px bg-ivory/40 float-slow" />
        </div>
      </section>

      {/* MANIFESTO */}
      <section id="approche" className="relative py-32 lg:py-48">
        <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-12 gap-16 px-6 lg:px-10">
          <div className="lg:col-span-4">
            <div className="sticky top-32">
              <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— Manifeste</span>
              <h2 className="serif text-5xl mt-6 leading-tight">Une ligne. <br /> Une exigence.</h2>
              <span className="gold-line mt-8 w-24 block" />
            </div>
          </div>
          <div className="lg:col-span-7 lg:col-start-6 space-y-10 serif text-2xl md:text-3xl leading-relaxed text-foreground/85">
            <p>
              Nous croyons qu'une transformation réussie ne se décrète pas.
              Elle se trace, patiemment, dans le dialogue et dans l'écoute.
            </p>
            <p className="italic text-muted-foreground">
              « La ligne juste est celle qui relie ce que l'organisation est
              à ce qu'elle veut devenir. »
            </p>
            <p>
              Notre cabinet réunit des consultants seniors, expérimentés dans
              l'industrie, la banque, l'assurance et le secteur public.
              Nous nous engageons sur nos livrables — et sur la relation.
            </p>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="relative py-32 bg-navy-deep text-ivory overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
            <div>
              <span className="text-[11px] uppercase tracking-widest-2 text-gold">— Notre méthode</span>
              <h2 className="serif text-5xl md:text-6xl mt-6 max-w-2xl leading-tight">
                Penser, déployer, <span className="italic text-gold-soft">mesurer.</span>
              </h2>
            </div>
            <p className="max-w-sm text-ivory/70 text-sm leading-relaxed">
              Trois pôles, une même ligne : de la direction stratégique
              à la preuve chiffrée, en passant par le geste technique.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-ivory/10">
            {services.map((s) => (
              <article
                key={s.n}
                className="card-hover group relative bg-navy-deep p-10 md:p-12 border border-transparent"
              >
                <div className="flex items-start justify-between mb-8">
                  <span className="serif text-6xl text-gold/40 group-hover:text-gold transition-colors duration-700">
                    {s.n}
                  </span>
                  <span className="h-px w-16 bg-gold self-center origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-700" />
                </div>
                <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-3">{s.step}</div>
                <h3 className="serif text-3xl mb-4">{s.title}</h3>
                <p className="text-ivory/70 leading-relaxed mb-8">{s.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {s.tags.map((t) => (
                    <span key={t} className="text-[11px] uppercase tracking-widest-2 text-ivory/50 border border-ivory/15 rounded-full px-3 py-1">
                      {t}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* LINE TEXTURE DIVIDER */}
      <section className="relative">
        <img src={lineTexture} alt="" loading="lazy" className="w-full h-40 md:h-64 object-cover" />
      </section>

      {/* REALISATIONS */}
      <section id="realisations" className="py-32 lg:py-40">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
            <div>
              <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— Réalisations</span>
              <h2 className="serif text-5xl md:text-6xl mt-6 leading-tight">
                Études de <span className="italic text-accent">cas.</span>
              </h2>
            </div>
            <Link to="/realisations" className="text-[12px] uppercase tracking-widest-2 link-underline">Toutes les réalisations →</Link>
          </div>

          <div className="divide-y divide-border border-y border-border">
            {cases.map((c, i) => (
              <Link
                to="/realisations"
                key={c.title}
                className="group grid grid-cols-12 items-center gap-6 py-8 md:py-10 px-2 hover:px-6 transition-all duration-500 hover:bg-secondary/60"
              >
                <span className="col-span-1 serif text-2xl text-muted-foreground">0{i + 1}</span>
                <span className="col-span-3 md:col-span-2 text-[11px] uppercase tracking-widest-2 text-accent">{c.pole}</span>
                <div className="col-span-8 md:col-span-5">
                  <div className="serif text-2xl md:text-3xl group-hover:translate-x-2 transition-transform duration-500">{c.title}</div>
                  <div className="text-sm text-muted-foreground mt-1">{c.client}</div>
                </div>
                <span className="hidden md:block col-span-3 text-right text-sm text-foreground/70">{c.kpi}</span>
                <span className="col-span-12 md:col-span-1 text-right text-2xl text-accent opacity-0 group-hover:opacity-100 group-hover:-translate-x-1 transition-all duration-500">↗</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section className="py-32 bg-secondary/60">
        <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-12 gap-14 px-6 lg:px-10 items-center">
          <div className="lg:col-span-5 relative">
            <div className="relative overflow-hidden rounded-sm">
              <img src={team1} alt="Portrait fondatrice" loading="lazy" className="w-full h-[560px] object-cover transition-transform duration-[2s] hover:scale-105" />
              <div className="absolute -bottom-1 -right-1 bg-background px-6 py-4">
                <div className="serif text-lg">Camille Roussel</div>
                <div className="text-xs uppercase tracking-widest-2 text-muted-foreground mt-1">Fondatrice · Associée</div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— L'équipe</span>
            <h2 className="serif text-5xl mt-6 leading-tight">Des visages, <br /> pas seulement des méthodes.</h2>
            <span className="gold-line mt-6 w-20 block" />
            <p className="mt-8 text-lg text-foreground/80 leading-relaxed">
              Nous sommes une équipe resserrée de consultants seniors. Chaque
              mission est portée par un associé — celui qui vous a rencontré
              reste votre interlocuteur du début à la fin.
            </p>
            <div className="mt-10 grid grid-cols-3 gap-8 border-t border-border pt-8">
              <div><div className="serif text-3xl">12</div><div className="text-xs uppercase tracking-widest-2 text-muted-foreground mt-2">consultants</div></div>
              <div><div className="serif text-3xl">3</div><div className="text-xs uppercase tracking-widest-2 text-muted-foreground mt-2">associés</div></div>
              <div><div className="serif text-3xl">2</div><div className="text-xs uppercase tracking-widest-2 text-muted-foreground mt-2">bureaux</div></div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-32">
        <div className="mx-auto max-w-4xl px-6 lg:px-10">
          <div className="text-center mb-16">
            <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— Questions fréquentes</span>
            <h2 className="serif text-5xl mt-6">Vous vous demandez <span className="italic text-accent">peut-être...</span></h2>
          </div>
          <div className="divide-y divide-border border-y border-border">
            {faqs.map((f, i) => {
              const isOpen = open === i;
              return (
                <button
                  key={f.q}
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full text-left py-8 group"
                >
                  <div className="flex items-start justify-between gap-6">
                    <span className="serif text-xl md:text-2xl">{f.q}</span>
                    <span className={`serif text-3xl text-accent transition-transform duration-500 ${isOpen ? "rotate-45" : ""}`}>+</span>
                  </div>
                  <div
                    className={`grid transition-all duration-700 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100 mt-5" : "grid-rows-[0fr] opacity-0"}`}
                  >
                    <div className="overflow-hidden">
                      <p className="text-foreground/75 leading-relaxed max-w-2xl">{f.a}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="relative py-32 bg-navy-deep text-ivory overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src={hero} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="relative mx-auto max-w-5xl px-6 lg:px-10 text-center">
          <span className="text-[11px] uppercase tracking-widest-2 text-gold">— Prenons contact</span>
          <h2 className="serif text-5xl md:text-7xl mt-6 leading-tight">
            Un projet, une intuition, <br />
            <span className="italic text-gold-soft">une conversation ?</span>
          </h2>
          <span className="gold-line mt-10 w-32 mx-auto block" />
          <p className="mt-8 text-lg text-ivory/70 max-w-xl mx-auto">
            Écrivez-nous quelques lignes. Nous vous rappelons sous 48h ouvrées.
          </p>
          <form className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto">
            <input placeholder="Nom" className="bg-transparent border-b border-ivory/25 py-3 focus:border-gold outline-none transition-colors placeholder:text-ivory/40" />
            <input placeholder="Email" className="bg-transparent border-b border-ivory/25 py-3 focus:border-gold outline-none transition-colors placeholder:text-ivory/40" />
            <input placeholder="Organisation" className="md:col-span-2 bg-transparent border-b border-ivory/25 py-3 focus:border-gold outline-none transition-colors placeholder:text-ivory/40" />
            <textarea placeholder="Votre message" rows={3} className="md:col-span-2 bg-transparent border-b border-ivory/25 py-3 focus:border-gold outline-none transition-colors placeholder:text-ivory/40 resize-none" />
            <button
              type="button"
              className="btn-gold md:col-span-2 mt-6 justify-self-center inline-flex items-center gap-3 rounded-full bg-gold px-10 py-4 text-[12px] uppercase tracking-widest-2 text-navy-deep font-medium hover:bg-gold-soft transition-colors duration-500"
            >
              <span className="relative z-10">Envoyer le message</span>
              <span className="relative z-10">→</span>
            </button>
          </form>
          <div className="mt-16 flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-sm text-ivory/70">
            <a href="mailto:contact@la-lignee.fr" className="link-underline">contact@la-lignee.fr</a>
            <span>·</span>
            <span>Paris — Lyon</span>
            <span>·</span>
            <span>+33 (0)1 42 00 00 00</span>
          </div>
        </div>
      </section>

      <SiteFooter />

    </div>
  );
}
