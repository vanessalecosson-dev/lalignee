import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";

export const Route = createFileRoute("/methode")({
  head: () => ({
    meta: [
      { title: "Notre méthode — La Lignée" },
      { name: "description", content: "Penser, déployer, mesurer : trois pôles d'expertise pour transformer avec méthode. Conseil & stratégie, Digital & tech, Data & analyse." },
      { property: "og:title", content: "Notre méthode — La Lignée" },
      { property: "og:description", content: "Penser, déployer, mesurer : trois pôles d'expertise pour transformer avec méthode." },
    ],
  }),
  component: MethodePage,
});

const poles = [
  {
    n: "01",
    step: "Penser",
    title: "Conseil & Stratégie",
    tagline: "La direction avant le mouvement.",
    desc: "Diagnostic, positionnement, plateforme de marque. Nous formalisons la vision et la trajectoire avant d'engager le mouvement.",
    livrables: ["Diagnostic 360°", "Plateforme de marque", "Roadmap stratégique", "Note de cadrage"],
    exemples: ["Repositionnement d'une ETI industrielle", "Plateforme de marque pour un acteur premium", "Feuille de route de transformation sur 36 mois"],
  },
  {
    n: "02",
    step: "Déployer",
    title: "Digital & Tech",
    tagline: "La stratégie qui prend forme.",
    desc: "Sites, contenus et solutions techniques sur mesure. Nos équipes conçoivent, développent et déploient les dispositifs qui font vivre la stratégie.",
    livrables: ["Sites & plateformes", "Applications sur mesure", "Design system", "Contenus & éditorial"],
    exemples: ["Refonte du site corporate d'un groupe familial", "Application interne de gestion opérationnelle", "Design system multi-marques"],
  },
  {
    n: "03",
    step: "Mesurer",
    title: "Data & Analyse",
    tagline: "La preuve qui éclaire la décision.",
    desc: "Tableaux de bord et lecture de la performance. Nous outillons vos équipes pour piloter avec des données lisibles et actionnables.",
    livrables: ["Tableaux de bord dirigeants", "Modèles d'attribution", "Analyses ad-hoc", "Formation à la donnée"],
    exemples: ["Dashboard exécutif d'un retailer omnicanal", "Cartographie de la performance commerciale", "Formation data literacy pour un CODIR"],
  },
];

function MethodePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <PageHero
        eyebrow="— Notre méthode"
        title={<>Penser, déployer, <span className="italic text-gold-soft">mesurer.</span></>}
        intro="Trois pôles, une même ligne. De la direction stratégique à la preuve chiffrée, en passant par le geste technique."
      />

      {/* Cheminement */}
      <section className="py-20 border-b border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            {poles.map((p, i) => (
              <div key={p.n} className="flex items-center gap-4">
                <span className="serif text-5xl text-accent">{p.n}</span>
                <div>
                  <div className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">{p.step}</div>
                  <div className="serif text-xl">{p.title}</div>
                </div>
                {i < poles.length - 1 && <span className="hidden md:block flex-1 h-px bg-border" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pôles détaillés */}
      {poles.map((p, i) => (
        <section
          key={p.n}
          id={p.step.toLowerCase()}
          className={`py-24 lg:py-32 ${i % 2 === 1 ? "bg-secondary/50" : ""}`}
        >
          <div className="mx-auto max-w-7xl px-6 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-14">
            <div className="lg:col-span-5">
              <div className="sticky top-32">
                <div className="flex items-baseline gap-4">
                  <span className="serif text-8xl text-accent/40">{p.n}</span>
                  <div className="text-[11px] uppercase tracking-widest-2 text-accent">{p.step}</div>
                </div>
                <h2 className="serif text-4xl md:text-5xl mt-6 leading-tight">{p.title}</h2>
                <p className="mt-4 text-lg italic text-muted-foreground">{p.tagline}</p>
                <span className="gold-line mt-8 w-20 block" />
              </div>
            </div>
            <div className="lg:col-span-6 lg:col-start-7">
              <p className="text-xl leading-relaxed text-foreground/85">{p.desc}</p>

              <div className="mt-10">
                <div className="text-[11px] uppercase tracking-widest-2 text-muted-foreground mb-4">Livrables types</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {p.livrables.map((l) => (
                    <div key={l} className="flex items-center gap-3 border-t border-border pt-3">
                      <span className="text-accent">—</span>
                      <span className="text-sm">{l}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-10">
                <div className="text-[11px] uppercase tracking-widest-2 text-muted-foreground mb-4">Exemples récents</div>
                <ul className="space-y-3">
                  {p.exemples.map((e) => (
                    <li key={e} className="serif text-lg text-foreground/80">· {e}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* CTA */}
      <section className="py-24 bg-navy-deep text-ivory">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="serif text-4xl md:text-5xl">Un projet à mettre en ligne ?</h2>
          <span className="gold-line mt-6 w-24 mx-auto block" />
          <p className="mt-6 text-ivory/75 max-w-xl mx-auto">Nous vous répondons sous 48h ouvrées, avec une première lecture de votre enjeu.</p>
          <Link to="/contact" className="btn-gold mt-10 inline-flex items-center gap-3 rounded-full bg-gold px-8 py-4 text-[12px] uppercase tracking-widest-2 text-navy-deep font-medium">
            <span className="relative z-10">Nous écrire</span><span className="relative z-10">→</span>
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
