import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { getRealisation, realisations, type Realisation } from "@/lib/realisations";

export const Route = createFileRoute("/realisations/$slug")({
  loader: ({ params }): Realisation => {
    const r = getRealisation(params.slug);
    if (!r) throw notFound();
    return r;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.title} — La Lignée` },
          { name: "description", content: loaderData.summary },
          { property: "og:title", content: `${loaderData.title} — La Lignée` },
          { property: "og:description", content: loaderData.summary },
        ]
      : [{ title: "Étude de cas — La Lignée" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: NotFound,
  component: CasePage,
});

function NotFound() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <section className="pt-40 pb-24 text-center px-6">
        <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— 404</span>
        <h1 className="serif text-5xl mt-6">Étude introuvable</h1>
        <Link to="/realisations" className="mt-8 inline-block link-underline text-sm uppercase tracking-widest-2">
          ← Toutes les réalisations
        </Link>
      </section>
      <SiteFooter />
    </div>
  );
}

function CasePage() {
  const r = Route.useLoaderData();
  const others = realisations.filter((x) => x.slug !== r.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      {/* Hero */}
      <section className="relative pt-40 pb-20 bg-navy-deep text-ivory">
        <div className="mx-auto max-w-5xl px-6 lg:px-10">
          <Link to="/realisations" className="text-[11px] uppercase tracking-widest-2 text-gold link-underline">
            ← Réalisations
          </Link>
          <div className="mt-8 flex items-center gap-4 flex-wrap text-[11px] uppercase tracking-widest-2 text-ivory/70">
            <span className="text-gold">{r.pole}</span>
            <span>·</span><span>{r.client}</span>
            <span>·</span><span>{r.year}</span>
            <span>·</span><span>{r.duration}</span>
          </div>
          <h1 className="serif text-[clamp(2.25rem,5vw,4.5rem)] mt-6 leading-[1.05] reveal">{r.title}</h1>
          <p className="mt-8 max-w-2xl text-lg text-ivory/75 reveal delay-1">{r.summary}</p>
        </div>
      </section>

      {/* Résultats bandeau */}
      <section className="bg-navy border-y border-ivory/10 text-ivory">
        <div className="mx-auto max-w-5xl px-6 lg:px-10 py-10 grid grid-cols-3 gap-6">
          {r.results.map((res: { k: string; v: string }) => (
            <div key={res.v}>
              <div className="serif text-4xl text-gold-soft">{res.k}</div>
              <div className="mt-2 text-xs uppercase tracking-widest-2 text-ivory/60">{res.v}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Corps */}
      <section className="py-24">
        <div className="mx-auto max-w-3xl px-6 lg:px-10 space-y-14">
          <div>
            <span className="text-[11px] uppercase tracking-widest-2 text-accent">— Le défi</span>
            <p className="serif text-2xl md:text-3xl leading-relaxed mt-5">{r.challenge}</p>
          </div>
          <div>
            <span className="text-[11px] uppercase tracking-widest-2 text-accent">— Notre approche</span>
            <ol className="mt-6 space-y-4">
              {r.approach.map((step: string, i: number) => (
                <li key={step} className="flex gap-5 border-t border-border pt-4">
                  <span className="serif text-2xl text-accent">0{i + 1}</span>
                  <span className="text-lg text-foreground/85 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* Autres cas */}
      <section className="py-20 bg-secondary/60 border-t border-border">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="flex items-end justify-between mb-10">
            <h2 className="serif text-3xl md:text-4xl">Autres études</h2>
            <Link to="/realisations" className="text-[11px] uppercase tracking-widest-2 link-underline">Toutes →</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border">
            {others.map((o) => (
              <Link key={o.slug} to="/realisations/$slug" params={{ slug: o.slug }} className="bg-background p-8 card-hover group">
                <div className="text-[11px] uppercase tracking-widest-2 text-accent mb-3">{o.pole}</div>
                <div className="serif text-xl group-hover:translate-x-1 transition-transform">{o.title}</div>
                <div className="mt-2 text-sm text-muted-foreground">{o.client}</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
