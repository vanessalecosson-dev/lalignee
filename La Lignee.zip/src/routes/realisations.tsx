import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";
import { realisations } from "@/lib/realisations";

export const Route = createFileRoute("/realisations")({
  head: () => ({
    meta: [
      { title: "Réalisations — La Lignée" },
      { name: "description", content: "Études de cas du cabinet La Lignée : stratégie, digital et data pour des ETI, groupes et maisons premium." },
      { property: "og:title", content: "Réalisations — La Lignée" },
      { property: "og:description", content: "Études de cas du cabinet La Lignée." },
    ],
  }),
  component: RealisationsPage,
});

const filters = ["Tous", "Penser", "Déployer", "Mesurer"] as const;

function RealisationsPage() {
  const [active, setActive] = useState<(typeof filters)[number]>("Tous");
  const list = useMemo(
    () => (active === "Tous" ? realisations : realisations.filter((r) => r.pole === active)),
    [active],
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <PageHero
        eyebrow="— Réalisations"
        title={<>Études de <span className="italic text-gold-soft">cas.</span></>}
        intro="Une sélection de missions récentes. Chaque étude retrace l'enjeu, notre approche et les résultats mesurés."
      />

      {/* Filtres */}
      <section className="border-b border-border sticky top-16 z-40 bg-background/90 backdrop-blur">
        <div className="mx-auto max-w-7xl px-6 lg:px-10 py-4 flex flex-wrap items-center gap-2">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`text-[11px] uppercase tracking-widest-2 rounded-full border px-4 py-2 transition-colors ${
                active === f
                  ? "bg-foreground text-background border-foreground"
                  : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
          <span className="ml-auto text-xs text-muted-foreground">{list.length} projet{list.length > 1 ? "s" : ""}</span>
        </div>
      </section>

      {/* Grille */}
      <section className="py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border">
            {list.map((r, i) => (
              <Link
                key={r.slug}
                to="/realisations/$slug"
                params={{ slug: r.slug }}
                className="group bg-background p-8 lg:p-10 relative overflow-hidden card-hover"
              >
                <div className="flex items-center justify-between mb-8">
                  <span className="serif text-2xl text-muted-foreground">0{i + 1}</span>
                  <span className="text-[11px] uppercase tracking-widest-2 text-accent">{r.pole}</span>
                </div>
                <div className="serif text-2xl md:text-3xl leading-tight group-hover:translate-x-1 transition-transform duration-500">
                  {r.title}
                </div>
                <div className="mt-2 text-sm text-muted-foreground">{r.client} · {r.year}</div>
                <p className="mt-6 text-sm text-foreground/70 leading-relaxed">{r.summary}</p>
                <div className="mt-8 flex items-center justify-between border-t border-border pt-5">
                  <span className="text-sm text-foreground/80">{r.kpi}</span>
                  <span className="text-accent text-xl opacity-0 group-hover:opacity-100 transition-opacity">↗</span>
                </div>
              </Link>
            ))}
          </div>
          {list.length === 0 && (
            <p className="text-center text-muted-foreground py-16">Aucune étude pour ce filtre.</p>
          )}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
