import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  const links = [
    { to: "/methode", label: "Notre méthode" },
    { to: "/realisations", label: "Réalisations" },
    { to: "/a-propos", label: "À propos" },
    { to: "/contact", label: "Contact" },
    { to: "/faq", label: "FAQ" },
  ];

  return (
    <div className="relative min-h-screen bg-navy-deep text-ivory overflow-hidden flex flex-col items-center justify-center px-6">
      <div className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='140' height='140'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.2 0 0 0 0 0.15 0 0 0 0 0.1 0 0 0 0.35 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`
        }}
      />
      <div className="relative z-10 text-center max-w-3xl">
        <div className="reveal">
          <span className="serif text-[clamp(8rem,20vw,16rem)] leading-none text-gold/20 select-none">404</span>
        </div>
        <h1 className="serif text-4xl md:text-5xl mt-2 reveal delay-1">
          Cette page est introuvable.
        </h1>
        <p className="mt-6 text-ivory/60 text-lg max-w-md mx-auto leading-relaxed reveal delay-2">
          La ligne que vous cherchez ne mène nulle part — ou peut-être pas encore.
        </p>

        <div className="mt-10 reveal delay-3">
          <Link
            to="/"
            className="btn-gold inline-flex items-center gap-3 rounded-full bg-gold px-8 py-4 text-[12px] uppercase tracking-widest-2 text-navy-deep font-medium hover:bg-gold-soft transition-colors duration-500"
          >
            <span className="relative z-10">Retour à l'accueil</span>
            <span className="relative z-10">←</span>
          </Link>
        </div>

        <div className="mt-16 reveal delay-4">
          <span className="text-[11px] uppercase tracking-widest-2 text-gold/70">— Explorer le site</span>
          <div className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-4">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="group flex flex-col items-center gap-3 p-5 border border-ivory/10 hover:border-gold/40 hover:bg-ivory/5 transition-all duration-500 rounded-sm"
              >
                <span className="text-sm font-medium text-ivory/90 group-hover:text-gold transition-colors duration-300">
                  {l.label}
                </span>
                <span className="h-px w-8 bg-gold/0 group-hover:bg-gold/60 transition-all duration-500" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "La Lignée — Cabinet de conseil" },
      { name: "description", content: "La Lignée, cabinet de conseil au service de la transformation des organisations : stratégie, digital, data et accompagnement humain." },
      { name: "author", content: "La Lignée" },
      { property: "og:title", content: "La Lignée — Cabinet de conseil" },
      { property: "og:description", content: "Stratégie, digital, data. Un accompagnement sur-mesure, tracé avec exigence." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=Inter:wght@300;400;500;600&display=swap" },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
