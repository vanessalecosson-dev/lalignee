import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import hero from "@/assets/hero-lignee.jpg";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — La Lignée" },
      { name: "description", content: "Prenons contact. Écrivez à La Lignée : un premier échange de 45 minutes, sans engagement, sous 48h ouvrées." },
      { property: "og:title", content: "Contact — La Lignée" },
      { property: "og:description", content: "Prenons contact. Une réponse sous 48h ouvrées." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);
  const [sujet, setSujet] = useState("Conseil & Stratégie");

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <section className="relative pt-40 pb-24 lg:pt-52 bg-navy-deep text-ivory overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img src={hero} alt="" className="h-full w-full object-cover ken-burns" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 lg:px-10 grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <span className="text-[11px] uppercase tracking-widest-2 text-gold">— Prenons contact</span>
            <h1 className="serif text-[clamp(2.5rem,5vw,4.5rem)] mt-6 leading-[1.05]">
              Un projet, une intuition, <br /><span className="italic text-gold-soft">une conversation ?</span>
            </h1>
            <span className="gold-line mt-8 w-24 block" />
            <p className="mt-8 text-lg text-ivory/75 max-w-md">
              Écrivez-nous quelques lignes. Nous vous rappelons sous 48h ouvrées pour un premier échange, sans engagement.
            </p>

            <div className="mt-12 space-y-6 text-sm">
              <div>
                <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-2">Email</div>
                <a href="mailto:contact@la-lignee.fr" className="link-underline text-ivory">contact@la-lignee.fr</a>
              </div>
              <div>
                <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-2">Téléphone</div>
                <div>+33 (0)1 42 00 00 00</div>
              </div>
              <div>
                <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-2">Bureaux</div>
                <div>Paris — 12 rue de la Paix, 75002</div>
                <div>Lyon — 8 quai Général Sarrail, 69006</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 lg:col-start-7">
            <div className="bg-ivory/[0.04] backdrop-blur-sm border border-ivory/10 p-8 lg:p-12 rounded-sm">
              {sent ? (
                <div className="py-12 text-center">
                  <span className="serif text-5xl text-gold">✓</span>
                  <h2 className="serif text-3xl mt-6">Message envoyé</h2>
                  <p className="mt-4 text-ivory/70">Nous revenons vers vous sous 48h ouvrées.</p>
                </div>
              ) : (
                <form
                  onSubmit={(e) => { e.preventDefault(); setSent(true); }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-5"
                >
                  <label className="flex flex-col gap-2">
                    <span className="text-[11px] uppercase tracking-widest-2 text-ivory/60">Nom</span>
                    <input required className="bg-transparent border-b border-ivory/25 py-2 focus:border-gold outline-none transition-colors" />
                  </label>
                  <label className="flex flex-col gap-2">
                    <span className="text-[11px] uppercase tracking-widest-2 text-ivory/60">Email</span>
                    <input required type="email" className="bg-transparent border-b border-ivory/25 py-2 focus:border-gold outline-none transition-colors" />
                  </label>
                  <label className="flex flex-col gap-2 md:col-span-2">
                    <span className="text-[11px] uppercase tracking-widest-2 text-ivory/60">Organisation</span>
                    <input className="bg-transparent border-b border-ivory/25 py-2 focus:border-gold outline-none transition-colors" />
                  </label>
                  <label className="flex flex-col gap-2 md:col-span-2">
                    <span className="text-[11px] uppercase tracking-widest-2 text-ivory/60">Sujet</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {["Conseil & Stratégie", "Digital & Tech", "Data & Analyse", "Autre"].map((s) => (
                        <button
                          type="button"
                          key={s}
                          onClick={() => setSujet(s)}
                          className={`text-[11px] uppercase tracking-widest-2 rounded-full px-4 py-2 border transition-colors ${
                            sujet === s ? "bg-gold text-navy-deep border-gold" : "border-ivory/25 text-ivory/70 hover:text-ivory"
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </label>
                  <label className="flex flex-col gap-2 md:col-span-2">
                    <span className="text-[11px] uppercase tracking-widest-2 text-ivory/60">Message</span>
                    <textarea required rows={4} className="bg-transparent border-b border-ivory/25 py-2 focus:border-gold outline-none transition-colors resize-none" />
                  </label>
                  <button
                    type="submit"
                    className="btn-gold md:col-span-2 mt-4 inline-flex items-center justify-center gap-3 rounded-full bg-gold px-10 py-4 text-[12px] uppercase tracking-widest-2 text-navy-deep font-medium hover:bg-gold-soft transition-colors"
                  >
                    <span className="relative z-10">Envoyer le message</span>
                    <span className="relative z-10">→</span>
                  </button>
                  <p className="md:col-span-2 text-[11px] text-ivory/50 text-center">
                    En envoyant ce message, vous acceptez notre politique de confidentialité.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
