import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — La Lignée" },
      { name: "description", content: "Réponses aux questions fréquentes sur les missions, l'organisation et l'engagement du cabinet La Lignée." },
      { property: "og:title", content: "FAQ — La Lignée" },
      { property: "og:description", content: "Réponses aux questions fréquentes sur nos missions." },
    ],
  }),
  component: FaqPage,
});

type FaqItem = { theme: string; q: string; a: string };

const faqs: FaqItem[] = [
  { theme: "Missions", q: "Comment démarre une mission avec La Lignée ?", a: "Par une conversation. Un premier échange de 45 minutes permet de comprendre l'enjeu, puis nous formalisons une note de cadrage avant tout engagement." },
  { theme: "Missions", q: "Quelle est la durée d'une mission type ?", a: "De 6 semaines pour un cadrage à 9 mois pour une transformation complète. Nous privilégions les formats resserrés à impact rapide." },
  { theme: "Missions", q: "Travaillez-vous en régie ou au forfait ?", a: "Les deux sont possibles. Nous recommandons le forfait pour les missions structurantes et la régie pour l'accompagnement dans la durée." },
  { theme: "Équipe", q: "Qui intervient sur ma mission ?", a: "Chaque mission est portée par un associé, qui reste votre interlocuteur du début à la fin, appuyé par 1 à 3 consultants seniors." },
  { theme: "Équipe", q: "Intervenez-vous en France uniquement ?", a: "Notre équipe est basée à Paris et Lyon, et nous intervenons partout en France ainsi qu'en Europe francophone." },
  { theme: "Confidentialité", q: "Comment protégez-vous la confidentialité ?", a: "Chaque mission est encadrée par un NDA. Les livrables et données restent votre propriété exclusive." },
  { theme: "Confidentialité", q: "Publiez-vous vos études de cas ?", a: "Uniquement avec l'accord explicite du client. Certaines études restent anonymisées, d'autres ne sont partagées qu'en entretien." },
  { theme: "Tarifs", q: "Comment sont établis vos honoraires ?", a: "Nos honoraires sont établis mission par mission, en fonction du périmètre et du calendrier. Nous partageons une proposition détaillée après la note de cadrage." },
];

function FaqPage() {
  const themes = useMemo(() => ["Tous", ...Array.from(new Set(faqs.map((f) => f.theme)))], []);
  const [active, setActive] = useState("Tous");
  const [open, setOpen] = useState<number | null>(0);

  const list = active === "Tous" ? faqs : faqs.filter((f) => f.theme === active);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <PageHero
        eyebrow="— Questions fréquentes"
        title={<>Vous vous demandez <span className="italic text-gold-soft">peut-être...</span></>}
        intro="Les réponses aux questions qu'on nous pose le plus souvent. Une autre interrogation ? Écrivez-nous, on répond vite."
      />

      <section className="py-14 lg:py-20">
        <div className="mx-auto max-w-4xl px-6 lg:px-10">
          <div className="flex flex-wrap gap-2 mb-10">
            {themes.map((t) => (
              <button
                key={t}
                onClick={() => { setActive(t); setOpen(null); }}
                className={`text-[11px] uppercase tracking-widest-2 rounded-full border px-4 py-2 transition-colors ${
                  active === t
                    ? "bg-foreground text-background border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="divide-y divide-border border-y border-border">
            {list.map((f, i) => {
              const isOpen = open === i;
              return (
                <button key={f.q} onClick={() => setOpen(isOpen ? null : i)} className="w-full text-left py-7 group">
                  <div className="flex items-start justify-between gap-6">
                    <div>
                      <div className="text-[10px] uppercase tracking-widest-2 text-accent mb-2">{f.theme}</div>
                      <span className="serif text-xl md:text-2xl">{f.q}</span>
                    </div>
                    <span className={`serif text-3xl text-accent transition-transform duration-500 ${isOpen ? "rotate-45" : ""}`}>+</span>
                  </div>
                  <div className={`grid transition-all duration-700 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100 mt-4" : "grid-rows-[0fr] opacity-0"}`}>
                    <div className="overflow-hidden">
                      <p className="text-foreground/75 leading-relaxed max-w-2xl">{f.a}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-16 text-center border-t border-border pt-14">
            <p className="text-muted-foreground">Une autre question ?</p>
            <Link to="/contact" className="btn-gold mt-6 inline-flex items-center gap-3 rounded-full bg-foreground px-8 py-4 text-[12px] uppercase tracking-widest-2 text-background">
              <span className="relative z-10">Nous écrire</span><span className="relative z-10">→</span>
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
