import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PageHero } from "@/components/page-hero";
import team1 from "@/assets/team-1.jpg";

export const Route = createFileRoute("/a-propos")({
  head: () => ({
    meta: [
      { title: "À propos — La Lignée" },
      { name: "description", content: "Manifeste, équipe et engagements du cabinet La Lignée. Un conseil resserré, exigeant et discret." },
      { property: "og:title", content: "À propos — La Lignée" },
      { property: "og:description", content: "Manifeste, équipe et engagements du cabinet La Lignée." },
    ],
  }),
  component: AboutPage,
});

const values = [
  { n: "01", title: "Discrétion", text: "Nous parlons peu de nos clients. Ce sont eux qui parlent de nous." },
  { n: "02", title: "Exigence", text: "Chaque livrable est signé par un associé. Le geste bien fait n'a pas de raccourci." },
  { n: "03", title: "Engagement", text: "Nous nous engageons sur les résultats — pas seulement sur la méthode." },
];

const team = [
  { name: "Camille Roussel", role: "Fondatrice · Associée", bio: "20 ans en conseil de direction, ex-BCG et directrice de la transformation d'un grand groupe." },
  { name: "Antoine Vidal", role: "Associé · Digital & Tech", bio: "Ingénieur, product leader. Il pilote les missions de conception et de mise en œuvre technique." },
  { name: "Léa Chastain", role: "Associée · Data & Analyse", bio: "Data scientist de formation, elle conçoit les dispositifs de pilotage et d'analyse." },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      <PageHero
        eyebrow="— À propos"
        title={<>Une ligne. <span className="italic text-gold-soft">Une exigence.</span></>}
        intro="La Lignée réunit des consultants seniors autour d'une conviction : les transformations réussies se tracent patiemment, dans l'écoute et le geste juste."
      />

      {/* Manifeste */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-12 gap-16 px-6 lg:px-10">
          <div className="lg:col-span-4">
            <div className="sticky top-32">
              <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— Manifeste</span>
              <h2 className="serif text-5xl mt-6 leading-tight">Notre parti pris.</h2>
              <span className="gold-line mt-6 w-24 block" />
            </div>
          </div>
          <div className="lg:col-span-7 lg:col-start-6 space-y-8 serif text-2xl md:text-3xl leading-relaxed text-foreground/85">
            <p>Nous croyons qu'une transformation réussie ne se décrète pas. Elle se trace, patiemment.</p>
            <p className="italic text-muted-foreground">« La ligne juste est celle qui relie ce que l'organisation est à ce qu'elle veut devenir. »</p>
            <p>Nous nous engageons sur nos livrables — et sur la relation.</p>
          </div>
        </div>
      </section>

      {/* Valeurs */}
      <section className="py-24 bg-navy-deep text-ivory">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="mb-14">
            <span className="text-[11px] uppercase tracking-widest-2 text-gold">— Valeurs</span>
            <h2 className="serif text-4xl md:text-5xl mt-6">Trois principes qui nous engagent.</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-ivory/10">
            {values.map((v) => (
              <div key={v.n} className="card-hover bg-navy-deep p-10">
                <div className="serif text-5xl text-gold/50">{v.n}</div>
                <h3 className="serif text-2xl mt-6">{v.title}</h3>
                <p className="mt-4 text-ivory/70 leading-relaxed">{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Équipe */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="mb-14 flex items-end justify-between flex-wrap gap-6">
            <div>
              <span className="text-[11px] uppercase tracking-widest-2 text-muted-foreground">— Équipe</span>
              <h2 className="serif text-5xl mt-6">Des visages, <span className="italic text-accent">pas seulement des méthodes.</span></h2>
            </div>
            <p className="max-w-sm text-sm text-muted-foreground">
              Une équipe resserrée de douze consultants, trois associés, deux bureaux. Un interlocuteur unique du début à la fin.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((m) => (
              <article key={m.name} className="group">
                <div className="relative overflow-hidden rounded-sm aspect-[3/4] bg-secondary">
                  <img src={team1} alt={m.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-[2s] group-hover:scale-105" />
                </div>
                <div className="mt-5">
                  <div className="serif text-2xl">{m.name}</div>
                  <div className="text-xs uppercase tracking-widest-2 text-muted-foreground mt-2">{m.role}</div>
                  <p className="mt-4 text-sm text-foreground/70 leading-relaxed">{m.bio}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-secondary/60">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="serif text-4xl md:text-5xl">Travaillons ensemble.</h2>
          <span className="gold-line mt-6 w-24 mx-auto block" />
          <p className="mt-6 text-foreground/75 max-w-xl mx-auto">Un premier échange de 45 minutes pour comprendre l'enjeu, sans engagement.</p>
          <Link to="/contact" className="btn-gold mt-10 inline-flex items-center gap-3 rounded-full bg-foreground px-8 py-4 text-[12px] uppercase tracking-widest-2 text-background">
            <span className="relative z-10">Prendre rendez-vous</span><span className="relative z-10">→</span>
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
