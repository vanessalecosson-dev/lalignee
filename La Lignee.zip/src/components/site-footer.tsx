import { Link } from "@tanstack/react-router";
import logo from "@/assets/lalignee-logo.png";

export function SiteFooter() {
  return (
    <footer className="bg-navy-deep border-t border-ivory/10 text-ivory/70">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-16 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-3">
            <img src={logo} alt="" className="h-9 w-auto opacity-90" />
            <span className="serif text-xl text-ivory">La Lignée</span>
          </div>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-ivory/60">
            Cabinet de conseil. Penser, déployer, mesurer — nous traçons la
            ligne juste entre la stratégie et la preuve.
          </p>
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-4">Explorer</div>
          <ul className="space-y-2 text-sm">
            <li><Link to="/methode" className="link-underline">Méthode</Link></li>
            <li><Link to="/a-propos" className="link-underline">À propos</Link></li>
            <li><Link to="/realisations" className="link-underline">Réalisations</Link></li>
            <li><Link to="/faq" className="link-underline">FAQ</Link></li>
            <li><Link to="/contact" className="link-underline">Contact</Link></li>
          </ul>
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-widest-2 text-gold mb-4">Contact</div>
          <ul className="space-y-2 text-sm">
            <li><a href="mailto:contact@la-lignee.fr" className="link-underline">contact@la-lignee.fr</a></li>
            <li>+33 (0)1 42 00 00 00</li>
            <li>Paris — Lyon</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ivory/10">
        <div className="mx-auto max-w-7xl px-6 lg:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs uppercase tracking-widest-2 text-ivory/50">
          <div>© 2026 La Lignée · Tous droits réservés</div>
          <div className="flex items-center gap-6">
            <Link to="/mentions-legales" className="link-underline">Mentions légales</Link>
            <Link to="/confidentialite" className="link-underline">Confidentialité</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
