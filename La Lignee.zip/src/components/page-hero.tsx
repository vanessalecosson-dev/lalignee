import type { ReactNode } from "react";

export function PageHero({
  eyebrow,
  title,
  intro,
  children,
}: {
  eyebrow: string;
  title: ReactNode;
  intro?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <section className="relative pt-40 pb-20 lg:pt-52 lg:pb-28 bg-navy-deep text-ivory overflow-hidden">
      <div className="absolute inset-0 opacity-[0.08] pointer-events-none">
        <div className="h-full w-full bg-[radial-gradient(circle_at_20%_20%,var(--gold),transparent_60%),radial-gradient(circle_at_80%_60%,var(--gold-soft),transparent_55%)]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        <div className="flex items-center gap-4 mb-6 reveal">
          <span className="h-px w-12 bg-gold" />
          <span className="text-[11px] uppercase tracking-widest-2 text-gold-soft">{eyebrow}</span>
        </div>
        <h1 className="serif text-[clamp(2.5rem,6vw,5.5rem)] leading-[1] reveal delay-1 max-w-4xl">
          {title}
        </h1>
        {intro && (
          <p className="mt-8 max-w-2xl text-lg text-ivory/75 reveal delay-2">{intro}</p>
        )}
        {children && <div className="mt-10 reveal delay-3">{children}</div>}
      </div>
    </section>
  );
}
