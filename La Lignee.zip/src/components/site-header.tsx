import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import logo from "@/assets/lalignee-logo.png";

const nav = [
  { to: "/methode", label: "Méthode" },
  { to: "/a-propos", label: "À propos" },
  { to: "/realisations", label: "Réalisations" },
  { to: "/faq", label: "FAQ" },
] as const;

export function SiteHeader({ transparent = false }: { transparent?: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const solid = !transparent || scrolled;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        solid
          ? "bg-background/85 backdrop-blur-md border-b border-border/60 py-3"
          : "bg-transparent py-6"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 lg:px-10">
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="La Lignée" className="h-9 w-auto" />
          <span className="serif text-lg tracking-wide">La Lignée</span>
        </Link>

        <nav className="hidden md:flex items-center gap-9 text-[13px] tracking-widest-2 uppercase text-muted-foreground">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="link-underline hover:text-foreground transition"
              activeProps={{ className: "text-foreground" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/contact"
            className="btn-gold hidden sm:inline-flex items-center gap-2 rounded-full border border-foreground/80 px-5 py-2.5 text-[12px] uppercase tracking-widest-2 text-foreground hover:bg-foreground hover:text-background transition-colors duration-500"
          >
            <span className="relative z-10">Nous écrire</span>
          </Link>
          <button
            aria-label="Menu"
            onClick={() => setOpen((o) => !o)}
            className="md:hidden text-foreground text-2xl leading-none"
          >
            {open ? "×" : "≡"}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden border-t border-border/60 bg-background/95 backdrop-blur">
          <nav className="flex flex-col px-6 py-4 gap-3 text-sm uppercase tracking-widest-2">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="py-2">
                {n.label}
              </Link>
            ))}
            <Link to="/contact" onClick={() => setOpen(false)} className="py-2 text-accent">
              Nous écrire
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
